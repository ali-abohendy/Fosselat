import { createRequire } from "module";
import fs from "fs";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
const data = JSON.parse(fs.readFileSync("/home/claude/pt4/questions.json"));
const BASE = "http://localhost:5199/";
let checks = 0, failures = 0;
function ok(c, m) { checks++; if (!c) { failures++; console.error("FAIL:", m); } }

function findQ(programId, prompt, optionTexts) {
  for (const t of data.tracks) for (const p of t.programs) {
    if (p.id !== programId) continue;
    for (const b of p.levelBanks) for (const q of b.questions) {
      if (q.prompt.trim() === prompt.trim()) {
        const set = new Set(q.options.map(o => o.trim()));
        if (optionTexts.every(o => set.has(o.trim()))) return q;
      }
    }
  }
  return null;
}

const browser = await chromium.launch();
const consoleErrors = [];
async function freshPage(vp) {
  const ctx = await browser.newContext({ viewport: vp || { width: 1280, height: 900 } });
  const page = await ctx.newPage();
  page.on("console", m => {
    if (m.type() === "error" && !/googleapis|fonts|favicon|Failed to load resource|ERR_TUNNEL|ERR_NAME/.test(m.text())) consoleErrors.push(m.text());
  });
  page.on("pageerror", e => consoleErrors.push(String(e)));
  return { ctx, page };
}
async function toSelfReport(page, trackSel, progText) {
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.click("button:has-text('Begin Assessment')");
  await page.click(trackSel);
  await page.click(`.pt-choice-row:has-text("${progText}")`);
  await page.click("button:has-text('Start Test')");
  await page.waitForSelector("text=only chooses where the test begins");
}
async function claim(page, nth) {
  for (let t = 0; t < 3; t++) {
    await page.click(`.pt-choice-list .pt-choice-row >> nth=${nth}`).catch(() => {});
    const got = await page.waitForSelector(".pt-stage-card", { timeout: 4000 }).catch(() => null);
    if (got) return;
  }
  throw new Error("claim failed");
}
async function answerLevel(page, progId, mode) {
  for (let i = 0; i < 10; i++) {
    await page.waitForSelector(".pt-card-question", { timeout: 15000 });
    const prompt = (await page.textContent(".pt-q-prompt")).trim();
    const opts = await page.$$eval(".pt-q-option", els =>
      els.map(e => e.querySelector("span:last-child").textContent.trim()));
    const q = findQ(progId, prompt, opts);
    ok(!!q, `question located: ${prompt.slice(0, 40)}`);
    let idx = 0;
    if (q) {
      const ci = opts.findIndex(o => o === q.options[q.correct].trim());
      idx = mode === "correct" ? Math.max(0, ci) : (Math.max(0, ci) + 1) % opts.length;
    }
    await page.click(`.pt-q-option >> nth=${idx}`);
    await page.click(".pt-q-actions button:has-text('Continue')");
    await page.waitForFunction(p => {
      const el = document.querySelector(".pt-q-prompt");
      return !el || el.textContent.trim() !== p;
    }, prompt, { timeout: 15000 }).catch(() => {});
  }
}
const QURAN = '.pt-choice-card:has-text("memorization and ijazah")';

/* 1. memorization full run + capture missing-word & two-excerpt renders */
{
  const { ctx, page } = await freshPage();
  await toSelfReport(page, QURAN, "Memorization & Revision");
  await claim(page, 1); // claim juz amma → start L1
  let gotMissing = false, gotParts = false, guard = 0;
  while (guard++ < 8) {
    if (await page.$(".pt-results-hero")) break;
    if (await page.$(".pt-stage-card")) await page.click(".pt-stage-card button");
    for (let i = 0; i < 10; i++) {
      await page.waitForSelector(".pt-card-question", { timeout: 15000 });
      // capture special renders
      if (!gotMissing && (await page.textContent(".pt-card-question")).includes("______")) {
        await page.waitForTimeout(750);
        await page.screenshot({ path: "shot-missing-word.png" });
        gotMissing = true;
      }
      if (!gotParts && await page.$(".pt-q-excerpt-label")) {
        const labels = await page.$$eval(".pt-q-excerpt-label", els => els.map(e => e.textContent));
        ok(labels.length === 2 && labels[0].includes("1") && labels[1].includes("2"),
           "two excerpts rendered as separate labelled boxes");
        const boxes = await page.$$(".pt-q-stimulus-part");
        ok(boxes.length === 2, "two separate stimulus boxes");
        await page.waitForTimeout(750);
        await page.screenshot({ path: "shot-two-excerpts.png" });
        gotParts = true;
      }
      const prompt = (await page.textContent(".pt-q-prompt")).trim();
      const opts = await page.$$eval(".pt-q-option", els =>
        els.map(e => e.querySelector("span:last-child").textContent.trim()));
      const q = findQ("memorization", prompt, opts);
      ok(!!q, `mem question located: ${prompt.slice(0, 40)}`);
      let idx = 0;
      if (q) idx = Math.max(0, opts.findIndex(o => o === q.options[q.correct].trim()));
      await page.click(`.pt-q-option >> nth=${idx}`);
      await page.click(".pt-q-actions button:has-text('Continue')");
      await page.waitForFunction(p => {
        const el = document.querySelector(".pt-q-prompt");
        return !el || el.textContent.trim() !== p;
      }, prompt, { timeout: 15000 }).catch(() => {});
      if (await page.$(".pt-stage-card, .pt-results-hero") && !(await page.$(".pt-card-question"))) break;
    }
    await page.waitForSelector(".pt-stage-card, .pt-results-hero", { timeout: 15000 });
  }
  await page.waitForSelector(".pt-results-hero", { timeout: 15000 });
  const tag = await page.textContent(".pt-rh-level-tag");
  ok(tag.includes("Level 4 of 4"), `memorization perfect run reaches top (${tag.trim()})`);
  console.log("memorization run ✓  missing-word seen:", gotMissing, " two-excerpt seen:", gotParts);
  await ctx.close();
}

/* 2. RT borderline: pass L1, fail L2 → L2 */
{
  const { ctx, page } = await freshPage();
  await toSelfReport(page, QURAN, "Reading & Tajweed");
  await claim(page, 1);
  await page.click(".pt-stage-card button");
  await answerLevel(page, "reading-tajweed", "correct");
  await page.waitForSelector(".pt-stage-card", { timeout: 15000 });
  await page.click(".pt-stage-card button");
  await answerLevel(page, "reading-tajweed", "wrong");
  await page.waitForSelector(".pt-results-hero", { timeout: 15000 });
  const tag = await page.textContent(".pt-rh-level-tag");
  ok(tag.includes("Level 2 of 4"), `RT pass L1 fail L2 → L2 (${tag.trim()})`);
  await ctx.close();
  console.log("RT borderline ✓");
}

/* 3. mobile 390px on a memorization two-excerpt/missing question */
{
  const { ctx, page } = await freshPage({ width: 390, height: 844 });
  await toSelfReport(page, QURAN, "Memorization & Revision");
  await claim(page, 2);
  await page.click(".pt-stage-card button");
  await page.waitForSelector(".pt-card-question");
  const m = await page.evaluate(() => ({
    sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth,
    fs: (() => { const el = document.querySelector(".pt-q-stimulus, .opt-ar"); return el ? parseFloat(getComputedStyle(el).fontSize) : 0; })(),
  }));
  ok(m.sw <= m.cw + 1, `no horizontal scroll at 390px (${m.sw} vs ${m.cw})`);
  ok(m.fs >= 20, `Arabic stays large on mobile (${m.fs}px)`);
  await page.waitForTimeout(700);
  await page.screenshot({ path: "shot-mobile-mem.png" });
  await ctx.close();
  console.log("mobile ✓");
}

ok(consoleErrors.length === 0, `no console errors (${consoleErrors.slice(0, 2).join(" | ")})`);
await browser.close();
console.log(`\nchecks: ${checks}`);
if (failures) { console.error(`FAILURES: ${failures}`); process.exit(1); }
console.log("ALL UI CHECKS PASSED");
