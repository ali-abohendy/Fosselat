/* Simulation harness for the v4.1 adaptive placement engine (one division). */
import fs from "fs";
import * as E from "./app/src/placementEngine.js";

const data = JSON.parse(fs.readFileSync(new URL("./questions.json", import.meta.url)));
let assertions = 0, failures = 0;
function ok(cond, msg) {
  assertions++;
  if (!cond) { failures++; console.error("FAIL:", msg); }
}

const cfg = E.configOf(data);
ok(cfg.masteryThreshold === 0.6, "threshold is 0.60");
ok(cfg.questionsPerLevel === 10, "10 questions per level");
ok(cfg.placementMode === "firstUnmastered", "placement mode");

// ---------- structure checks
const structure = {
  quran: { "reading-tajweed": 4, "memorization": 4, "ijazah": 2 },
  arabic: { "foundation": 4, "advanced": 6 },
  "islamic-studies": { "comprehensive": 6 },
};
ok(data.tracks.length === 3, "three tracks");
for (const t of data.tracks) {
  const want = structure[t.id];
  ok(!!want, `known track ${t.id}`);
  ok(t.programs.length === Object.keys(want).length, `${t.id}: program count`);
  for (const p of t.programs) {
    ok(want[p.id] === p.levels.length, `${p.id}: ${want[p.id]} levels (has ${p.levels.length})`);
    ok(p.levelBanks.length === p.levels.length, `${p.id}: bank per level`);
    for (const b of p.levelBanks) {
      ok(b.questions.length >= 16, `${p.id} L${b.level}: pool ${b.questions.length} >= 16`);
      for (const q of b.questions) {
        ok(q.level === b.level && q.program === p.id, `${q.id}: level/program tags`);
        ok(!("audience" in q), `${q.id}: no audience field`);
        ok(Number.isInteger(q.correct) && q.correct >= 0 && q.correct < q.options.length, `${q.id}: correct index`);
        ok(q.correctAnswer === q.options[q.correct], `${q.id}: correctAnswer matches`);
        ok(!!q.skill && !!q.topic && !!q.competency, `${q.id}: metadata present`);
      }
    }
    const claims = p.selfReport.options.map(o => o.claimLevel);
    ok(Math.min(...claims) === 1 && Math.max(...claims) === p.levels.length,
       `${p.id}: self-report claims span levels`);
  }
}
const rawStr = JSON.stringify(data);
ok(!/"audience"/.test(rawStr), "no audience keys anywhere");
ok(!/"kids"|"adults"/.test(rawStr), "no kids/adults division anywhere");

// ---------- v4.1 curriculum-alignment checks
for (const t of data.tracks) for (const p of t.programs) for (const b of p.levelBanks) {
  for (const q of b.questions) {
    ok(!/^Which of these is from Surah/.test(q.prompt), `${q.id}: banned pick-verse type removed`);
    ok(q.skill !== "Passage Discrimination", `${q.id}: is/is-not discrimination removed`);
    if (/Both (lines|excerpts)/.test(q.prompt)) {
      ok(Array.isArray(q.arabicParts) && q.arabicParts.length === 2,
         `${q.id}: two-excerpt item carries arabicParts[2]`);
      ok(!q.arabic, `${q.id}: two-excerpt item has no joined stimulus`);
    }
    if ((q.arabic || "").includes("______")) {
      ok(q.optionsArabic === true, `${q.id}: missing-word item uses Arabic options`);
      ok(q.options.length === 4, `${q.id}: missing-word item has 4 options`);
      ok(q.skill === "Missing Word", `${q.id}: missing-word skill tag`);
    }
    if (p.id === "foundation") {
      ok(!["Vocabulary", "Word Groups", "Sentences", "Words in Context"].includes(q.skill),
         `${q.id}: foundation vocab/translation skill removed`);
      ok(!/^Which word means/.test(q.prompt), `${q.id}: foundation meaning question removed`);
      ok(!/does NOT belong/.test(q.prompt), `${q.id}: odd-one-out removed`);
      ok(!/plural of/i.test(q.prompt), `${q.id}: plural-formation removed`);
      ok(!/demonstrative/i.test(q.prompt), `${q.id}: demonstrative removed`);
      ok(!/What does this sentence mean/.test(q.prompt), `${q.id}: sentence-meaning removed`);
      ok(!/letters joined|NOT join|DOES join/.test(q.prompt), `${q.id}: joining trivia removed`);
    }
    if (p.id === "reading-tajweed" && q.level === 1 &&
        ["Short Vowels", "Reading Words", "Similar Letters"].includes(q.skill)) {
      const probe = (q.arabic || "") + (q.optionsArabic ? q.options[q.correct] : "");
      for (const ch of ["ْ", "ّ", "ً", "ٌ", "ٍ", "ٰ"]) {
        ok(!probe.includes(ch), `${q.id}: RT L1 reading item free of later marks (${ch})`);
      }
    }
    if (p.id === "advanced") {
      ok(!/does NOT belong/.test(q.prompt), `${q.id}: PF odd-one-out removed`);
    }
  }
}

// position balance & length bias per bank
for (const t of data.tracks) for (const p of t.programs) for (const b of p.levelBanks) {
  const pos = [0, 0, 0, 0];
  b.questions.forEach(q => pos[q.correct] = (pos[q.correct] || 0) + 1);
  const n = b.questions.length;
  ok(Math.max(...pos) <= Math.ceil(n / 4) + 2, `${p.id} L${b.level}: correct-position spread ${pos}`);
  const nonAr = b.questions.filter(q => !q.optionsArabic);
  if (nonAr.length >= 6) {
    const cor = nonAr.map(q => q.options[q.correct].length);
    const dis = nonAr.flatMap(q => q.options.filter((_, i) => i !== q.correct).map(o => o.length));
    const mc = cor.reduce((a, b) => a + b, 0) / cor.length;
    const md = dis.reduce((a, b) => a + b, 0) / dis.length;
    ok(Math.abs(mc - md) / md < 0.30, `${p.id} L${b.level}: length bias ${mc.toFixed(1)} vs ${md.toFixed(1)}`);
  }
}

// ---------- run helper
function runStudent(trackId, programId, claim, answerFn, seed) {
  const sess = E.startSession(data, trackId, programId, claim, seed);
  const servedIds = new Set();
  let guard = 0;
  while (!sess.finished) {
    guard++;
    ok(guard < 12, "terminates in < 12 level visits");
    const st = sess.perLevel[sess.currentLevel];
    const { program } = E.resolve(data, sess);
    for (let i = 0; i < st.slots.length; i++) {
      const pres = E.presentSlot(data, sess, i);
      ok(pres.level === sess.currentLevel, "question belongs to current level (never mixed)");
      ok(!servedIds.has(pres.id), `question ${pres.id} not repeated in session`);
      servedIds.add(pres.id);
      const q = E.questionById(program, sess.currentLevel, pres.id);
      const pick = answerFn(sess.currentLevel, q, pres, i);
      E.answerSlot(data, sess, i, pick);
    }
    E.gradeLevel(data, sess);
    E.advance(data, sess);
  }
  return { sess, result: E.finalizeResult(data, sess) };
}
const correctPick = pres => pres._slotOrder.findIndex(k => k === pres.correct);

function abilityFn(k) {
  return (lvl, q, pres) => {
    if (lvl <= k) return correctPick(pres);
    const wrong = pres._slotOrder.findIndex(kk => kk !== q.correct);
    return wrong;
  };
}

// ---------- deterministic placement across every program/claim/ability
let students = 0;
for (const t of data.tracks) for (const p of t.programs) {
  const maxL = p.levels.length;
  for (let claim = 1; claim <= maxL; claim++) {
    for (let k = 0; k <= maxL; k++) {
      students++;
      const { sess, result } = runStudent(t.id, p.id, claim, abilityFn(k), 1000 + students);
      const expected = k === 0 ? 1 : Math.min(k + 1, maxL);
      ok(result.level.id === expected,
         `${p.id} claim=${claim} ability=${k}: placed L${result.level.id}, expected L${expected}`);
      ok(result.highestMastered === (k === 0 ? null : Math.min(k, maxL)),
         `${p.id} claim=${claim} ability=${k}: highestMastered check`);
      for (const ls of result.levelScores) {
        ok(ls.mastered === (ls.level <= k), `${p.id}: level ${ls.level} mastery flag`);
      }
      const v = [...sess.visited].sort((a, b) => a - b);
      for (let i = 1; i < v.length; i++) ok(v[i] - v[i - 1] === 1, "visited levels contiguous");
    }
  }
}
console.log(`deterministic students: ${students}`);

// ---------- threshold exactness: 6/10 passes, 5/10 fails
{
  const t = data.tracks[0], p = t.programs[0];
  function nOfTen(n) {
    let served = 0;
    return (lvl, q, pres) => {
      served++;
      if (served <= n) return correctPick(pres);
      return pres._slotOrder.findIndex(kk => kk !== q.correct);
    };
  }
  const r6 = runStudent(t.id, p.id, 1, nOfTen(6), 7).result;
  ok(r6.levelScores.find(l => l.level === 1).mastered === true, "60% (6/10) passes");
  const r5 = runStudent(t.id, p.id, 1, nOfTen(5), 8).result;
  ok(r5.levelScores.find(l => l.level === 1).mastered === false, "50% (5/10) fails");
  ok(r5.level.id === 1, "failing L1 places at L1");
}

// ---------- spec walk-through examples
{
  const t = data.tracks[1], p = t.programs[1]; // advanced (6 levels)
  const ex1 = runStudent(t.id, p.id, 2, abilityFn(2), 42).result;
  ok(ex1.level.id === 3, `example 1 -> L3 (got ${ex1.level.id})`);
  const ex2 = runStudent(t.id, p.id, 4, abilityFn(1), 43).result;
  ok(ex2.level.id === 2, `example 2 -> L2 (got ${ex2.level.id})`);
  const ex3 = runStudent(t.id, p.id, 3, abilityFn(3), 44).result;
  ok(ex3.level.id === 4, `example 3 -> L4 (got ${ex3.level.id})`);
  const ex4 = runStudent(t.id, p.id, 6, abilityFn(6), 45).result;
  ok(ex4.level.id === 6, `example 4 -> top level (got ${ex4.level.id})`);
}

// ---------- self-report never inflates; age never affects placement
for (const t of data.tracks) for (const p of t.programs) {
  const maxL = p.levels.length;
  const rLow = runStudent(t.id, p.id, maxL, abilityFn(0), 99).result;
  ok(rLow.level.id === 1, `${p.id}: over-claimer with no ability lands at L1`);
  const s1 = E.startSession(data, t.id, p.id, 2, 555); s1.age = 7;
  const s2 = E.startSession(data, t.id, p.id, 2, 555); s2.age = 45;
  ok(JSON.stringify(s1.perLevel) === JSON.stringify(s2.perLevel),
     `${p.id}: age has zero effect on question selection`);
}

// ---------- guessing
{
  let placedAbove1 = 0, trials = 400;
  for (let i = 0; i < trials; i++) {
    const rng = E.mulberry32(9000 + i);
    const guess = (lvl, q, pres) => Math.floor(rng() * pres.options.length);
    const { result } = runStudent("quran", "reading-tajweed", 3, guess, 20000 + i);
    if (result.level.id > 1 && result.highestMastered) placedAbove1++;
  }
  const rate = placedAbove1 / trials;
  ok(rate < 0.08, `pure guessing rarely proves a level (rate=${(rate * 100).toFixed(1)}%)`);
  console.log(`guess mastery rate: ${(rate * 100).toFixed(1)}% over ${trials} trials`);
}

// ---------- resume determinism
{
  const t = data.tracks[2], p = t.programs[0];
  const sess = E.startSession(data, t.id, p.id, 3, 777);
  for (let i = 0; i < 4; i++) {
    const pres = E.presentSlot(data, sess, i);
    E.answerSlot(data, sess, i, correctPick(pres));
  }
  const snap = JSON.parse(JSON.stringify(E.snapshotOf(sess)));
  const sess2 = E.rehydrate(data, snap);
  ok(!!sess2, "rehydrate accepts snapshot");
  ok(JSON.stringify(sess2.perLevel[sess2.currentLevel].slots) ===
     JSON.stringify(sess.perLevel[sess.currentLevel].slots), "resume keeps same questions & option order");
  function finish(s) {
    while (!s.finished) {
      const st = s.perLevel[s.currentLevel];
      for (let i = 0; i < st.slots.length; i++) {
        if (st.answers[i] !== undefined && st.answers[i] !== null) continue;
        const pres = E.presentSlot(data, s, i);
        E.answerSlot(data, s, i, correctPick(pres));
      }
      E.gradeLevel(data, s); E.advance(data, s);
    }
    return E.finalizeResult(data, s);
  }
  const r1 = finish(sess), r2 = finish(sess2);
  ok(r1.level.id === r2.level.id, "resumed session reaches identical placement");
}

// ---------- fuzz
{
  const rng = E.mulberry32(31337);
  let runs = 0;
  for (const t of data.tracks) for (const p of t.programs) {
    for (let i = 0; i < 40; i++) {
      runs++;
      const maxL = p.levels.length;
      const claim = 1 + Math.floor(rng() * maxL);
      const k = Math.floor(rng() * (maxL + 1));
      const fn = (lvl, q, pres) => {
        const r = rng();
        if (r < 0.06) return undefined;
        const knows = lvl <= k ? 0.92 : 0.22;
        if (rng() < knows) return correctPick(pres);
        return Math.floor(rng() * pres.options.length);
      };
      const { result } = runStudent(t.id, p.id, claim, fn, 40000 + runs);
      ok(result.level.id >= 1 && result.level.id <= maxL, "placement within range");
      ok(result.levelScores.length >= 1, "at least one level scored");
    }
  }
  console.log(`fuzz runs: ${runs}`);
}

console.log(`\nassertions: ${assertions}`);
if (failures) { console.error(`FAILURES: ${failures}`); process.exit(1); }
console.log("ALL CHECKS PASSED");
