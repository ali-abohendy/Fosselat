# -*- coding: utf-8 -*-
"""Generates missing-word memorization items from the Qur'anic corpus.

Guarantees per item:
  · the blanked word is the one word that continues the shown context anywhere
    in the corpus where that context occurs (no second defensible answer);
  · no distractor forms a real Qur'anic sequence in that slot;
  · distractors are realistic (same-surah words of similar shape);
  · the blank is one word; the excerpt stays short.
Deterministic (seeded).
"""
import json, random, re, sys

sys.path.insert(0, "/home/claude/fosselat")
import quran_items as QI

SURAH_JUZ = {}
_bounds = [(1,1),(2,2),(3,2),(4,3),(5,4),(6,4),(7,5),(8,6),(9,7),(10,8),(11,9),(12,11),
 (13,12),(14,15),(15,17),(16,18),(17,21),(18,23),(19,25),(20,27),(21,29),
 (22,33),(23,36),(24,39),(25,41),(26,46),(27,51),(28,58),(29,67),(30,78)]
for i in range(1, 115):
    jz = 1
    for j, s in _bounds:
        if i >= s: jz = j
    SURAH_JUZ[i] = jz

def level_surahs(level):
    out = []
    for n in range(1, 115):
        if n in (36, 56, 18):
            lv = 2
        else:
            jz = SURAH_JUZ[n]
            lv = 1 if jz == 30 else 2 if jz == 29 else 3 if jz >= 15 else 4
        if lv == level: out.append(n)
    return out

# tokenized, cleaned verses per surah
VERSES = {}   # n -> list[list[token]]
for n in range(1, 115):
    VERSES[n] = [QI.clean_text(v["text"]).split() for v in QI.verses(n)]

# corpus-wide within-verse token streams for uniqueness checks
ALL_STREAMS = [(n, vi, toks) for n in VERSES for vi, toks in enumerate(VERSES[n])]

def continuations(pre):
    """All words that follow the exact token sequence `pre` anywhere (within a verse)."""
    k = len(pre)
    outs = set()
    for n, vi, toks in ALL_STREAMS:
        for i in range(len(toks) - k):
            if toks[i:i+k] == pre:
                outs.add(toks[i+k])
    return outs

def seq_exists(seq):
    k = len(seq)
    for n, vi, toks in ALL_STREAMS:
        for i in range(len(toks) - k + 1):
            if toks[i:i+k] == seq:
                return True
    return False

STOP = set("من في ما لا إن أن على إلى لم لن هو هي ثم قد إذ إذا أو بل لو كل عن مع".split())
def bare(w):
    return re.sub(r"[ً-ْٓ-ٰٟ]", "", w)

def good_target(w):
    b = bare(w)
    return len(b) >= 3 and b not in STOP and "۝" not in w

def make_items(level, want, seed):
    rnd = random.Random(seed)
    surahs = level_surahs(level)
    rnd.shuffle(surahs)
    items, used_slots, used_words = [], set(), set()
    for n in surahs * 3:                                   # a few passes
        if len(items) >= want: break
        verses = VERSES[n]
        vi = rnd.randrange(len(verses))
        toks = verses[vi]
        if len(toks) < 5: continue
        # choose blank position with >=2 tokens before, >=1 after
        pos_candidates = [i for i in range(2, len(toks) - 1) if good_target(toks[i])]
        rnd.shuffle(pos_candidates)
        placed = False
        for pos in pos_candidates:
            correct = toks[pos]
            if bare(correct) in used_words: continue
            preN = min(4, pos)
            pre = toks[pos - preN:pos]
            post = toks[pos + 1:pos + 3]
            # ambiguity check 1: this context always continues with `correct`
            conts = continuations(pre)
            if conts != {correct}:
                # try longer context
                if pos >= 5:
                    pre = toks[pos - 5:pos]; preN = 5
                    conts = continuations(pre)
                if conts != {correct}: continue
            slot = (n, vi, pos)
            if slot in used_slots: continue
            excerpt_pre = " ".join(pre)
            excerpt_post = " ".join(post)
            excerpt = (excerpt_pre + "  ______  " + excerpt_post).strip()
            if not (28 <= len(excerpt) <= 150): continue
            if QI.leaks(excerpt_pre + " " + excerpt_post, n): continue
            # distractors: same-surah words, similar shape, not fitting the slot
            pool = sorted({w for vv in verses for w in vv
                           if good_target(w) and bare(w) != bare(correct)
                           and w not in pre and w not in post})
            pool.sort(key=lambda w: (abs(len(w) - len(correct)), rnd.random()))
            distr = []
            for w in pool:
                if len(distr) == 3: break
                if any(bare(w) == bare(x) for x in distr): continue
                if seq_exists(pre + [w]): continue          # would form a real sequence
                distr.append(w)
            if len(distr) < 3:
                # top up from neighbouring surahs in the same level band
                for n2 in surahs:
                    if len(distr) == 3: break
                    if n2 == n: continue
                    for vv in VERSES[n2]:
                        for w in vv:
                            if len(distr) == 3: break
                            if not good_target(w) or bare(w) == bare(correct): continue
                            if abs(len(w) - len(correct)) > 3: continue
                            if any(bare(w) == bare(x) for x in distr): continue
                            if seq_exists(pre + [w]): continue
                            distr.append(w)
            if len(distr) < 3: continue
            opts = [correct] + distr
            lens = [len(o) for o in opts]
            if max(lens) > 2.0 * max(4, min(lens)) and min(lens) >= 25: continue
            used_slots.add(slot); used_words.add(bare(correct))
            diff = "medium" if level <= 2 and rnd.random() < 0.6 else "hard"
            items.append({
                "skill": "Missing Word", "difficulty": diff,
                "prompt": "Choose the exact word that completes this passage:",
                "arabic": excerpt, "options": opts, "correct": 0, "points": 1,
                "options_arabic": True, "_src": f"gen-missing-L{level}",
            })
            placed = True
            break
        if not placed: continue
    return items

if __name__ == "__main__":
    out = []
    WANT = {1: 10, 2: 10, 3: 9, 4: 8}
    for lv, want in WANT.items():
        got = make_items(lv, want, seed=20260820 + lv)
        print(f"L{lv}: generated {len(got)}")
        for it in got: it["_lvl"] = lv
        out.extend(got)
    json.dump(out, open("missing_items.json", "w"), ensure_ascii=False, indent=1)
    print("wrote missing_items.json:", len(out))
    for it in out[:6]:
        print(f"  L{it['_lvl']} [{it['difficulty']}] {it['arabic'][:70]} | opts: {' / '.join(o[:14] for o in it['options'])}")
