# -*- coding: utf-8 -*-
"""Curriculum-alignment curation applied to the remapped pools before assembly.

  Memorization : drop ambiguous "which of these is from Surah X" / is-isn't
                 items; split two-excerpt stimuli into arabicParts; verify
                 passage→surah items are globally unique; add missing-word items.
  Foundation   : reading-foundation only — drop vocabulary meanings, odd-one-out,
                 plurals, word assembly, letter-connection trivia, sentence
                 translation, demonstratives; move mis-levelled items.
  Reading&Tajweed: L1 = letters/names/sounds/short vowels only; sukoon items
                 → L3, madd words → L2 (relabelled easy).
  Post-Foundation: drop odd-one-out (ambiguity risk).
"""
import json, re, sys

sys.path.insert(0, "/home/claude/fosselat")
import quran_items as QI

REPORT = {"removed": [], "moved": [], "reformatted": 0, "added": 0}

def _rm(pool, pred, reason):
    keep, gone = [], []
    for q in pool:
        (gone if pred(q) else keep).append(q)
    for q in gone:
        REPORT["removed"].append((reason, q["prompt"][:70]))
    return keep

def _take(pool, pred):
    keep, taken = [], []
    for q in pool:
        (taken if pred(q) else keep).append(q)
    return keep, taken

# ---------------------------------------------------------------- memorization
_SURAH_CLEAN = {}
def surah_clean(n):
    if n not in _SURAH_CLEAN:
        _SURAH_CLEAN[n] = QI.clean_text(" ".join(v["text"] for v in QI.verses(n)))
    return _SURAH_CLEAN[n]

def surahs_containing(fragment):
    frag = re.sub(r"\s+", " ", QI.clean_text(fragment or "").strip())
    if len(frag) < 10: return []
    probe = frag[:40]
    return [n for n in range(1, 115) if probe in surah_clean(n)]

def curate_memorization(pools):
    missing = json.load(open("missing_items.json"))
    seen_parts = set()
    for lv in (1, 2, 3, 4):
        key = f"memorization|{lv}"
        pool = pools.get(key, [])
        # 1. drop the banned pick-the-verse family
        pool = _rm(pool, lambda q: q["prompt"].startswith("Which of these is from Surah"),
                   "mem: pick-verse-from-surah")
        pool = _rm(pool, lambda q: q["skill"] == "Passage Discrimination",
                   "mem: is/is-not discrimination")
        out = []
        for q in pool:
            ar = q.get("arabic") or ""
            # 2. two-excerpt items → clearly separated parts
            if "Both" in q["prompt"] and "\n" in ar:
                parts = [p.strip() for p in ar.split("\n") if p.strip()]
                if len(parts) >= 2:
                    q = dict(q)
                    q["arabicParts"] = parts[:2]
                    q.pop("arabic", None)
                    REPORT["reformatted"] += 1
                    # each excerpt must live in exactly one surah
                    ok = all(len(surahs_containing(p)) == 1 for p in q["arabicParts"])
                    if not ok:
                        REPORT["removed"].append(("mem: two-excerpt not unique", q["prompt"][:70]))
                        continue
                    pk = frozenset(q["arabicParts"]) | frozenset([q["prompt"]])
                    if pk in seen_parts:
                        REPORT["removed"].append(("mem: duplicate two-excerpt pair", q["prompt"][:70]))
                        continue
                    seen_parts.add(pk)
            # 3. passage→surah items must be globally unique
            elif ar and ("surah is this from" in q["prompt"] or "which surah is this passage" in q["prompt"].lower()):
                hits = surahs_containing(ar)
                if len(hits) != 1:
                    REPORT["removed"].append(("mem: passage not unique", ar[:50]))
                    continue
            out.append(q)
        # 4. add missing-word recall items
        add = [dict(m) for m in missing if m["_lvl"] == lv]
        REPORT["added"] += len(add)
        pools[key] = out + add
    return pools

# ---------------------------------------------------------------- foundation
def curate_foundation(pools):
    f1 = pools.get("foundation|1", [])
    f2 = pools.get("foundation|2", [])
    f3 = pools.get("foundation|3", [])
    f4 = pools.get("foundation|4", [])

    # F1 removals: joining trivia, word assembly, alphabet-count trivia
    f1 = _rm(f1, lambda q: "join" in q["prompt"].lower() and "letter" in q["prompt"].lower(),
             "af1: letter-connection/assembly")
    f1 = _rm(f1, lambda q: "How many letters are there in the Arabic alphabet" in q["prompt"],
             "af1: alphabet-count trivia")
    f1 = _rm(f1, lambda q: "all its letters joined" in q["prompt"], "af1: joined-word trivia")

    # F1 → F2 moves (long vowels / sukoon words taught later)
    def to_f2(q):
        pr = q["prompt"]
        return ((q.get("arabic") == "سْ") or "read 'bayt'" in pr or
                "read 'madrasa' (a school)" in pr or "read 'jameel'" in pr or
                "read 'muhandis'" in pr)
    f1, mv = _take(f1, to_f2)
    for q in mv:
        q = dict(q); q["difficulty"] = "easy" if q.get("arabic") == "سْ" or "bayt" in q["prompt"] else q["difficulty"]
        REPORT["moved"].append(("AF L1→L2", q["prompt"][:60])); f2.append(q)

    # F2 removals: vocabulary meanings
    f2 = _rm(f2, lambda q: q["prompt"].startswith("Which word means"), "af2: vocabulary meaning")

    # F3 removals: vocabulary / word groups / plurals / odd-one-out
    f3 = _rm(f3, lambda q: q["skill"] in ("Vocabulary", "Word Groups"), "af3: vocabulary & groups")

    # F4 removals: sentence translation, demonstratives, question-word vocab
    f4 = _rm(f4, lambda q: q["skill"] in ("Sentences", "Words in Context"),
             "af4: sentence meaning / vocab-grammar")

    pools["foundation|1"], pools["foundation|2"] = f1, f2
    pools["foundation|3"], pools["foundation|4"] = f3, f4
    return pools

# ---------------------------------------------------------------- reading-tajweed
def curate_rt(pools):
    l1 = pools.get("reading-tajweed|1", [])
    l2 = pools.get("reading-tajweed|2", [])
    l3 = pools.get("reading-tajweed|3", [])

    MADD_WORDS = ("read 'kabeer'", "read 'ta'aam'", "read 'noor'", "read 'jadeed'")
    SUKOON_WORDS = ("read 'sabr'", "read 'hajj'", "read 'shams'", "read 'zuhr'",
                    "read 'ghayr'", "read 'ard'", "read 'al-hamdu'",
                    "read 'istighfaar'", "read 'muslim'")

    def to_l2(q):
        pr = q["prompt"]
        return any(w in pr for w in MADD_WORDS) or \
               (pr == "How is this word read?" and q.get("arabic") == "صَغِير")
    def to_l3(q):
        pr = q["prompt"]
        return any(w in pr for w in SUKOON_WORDS) or \
               (q.get("arabic") in ("بْ", "قُلْ", "مَنْ"))

    l1, mv2 = _take(l1, to_l2)
    for q in mv2:
        q = dict(q); q["difficulty"] = "easy"
        REPORT["moved"].append(("RT L1→L2", q["prompt"][:60])); l2.append(q)
    l1, mv3 = _take(l1, to_l3)
    for q in mv3:
        q = dict(q); q["difficulty"] = "easy"
        REPORT["moved"].append(("RT L1→L3", q["prompt"][:60])); l3.append(q)

    # subtle sound discriminations are the hardest thing left in L1
    for q in l1:
        if "'thin'" in q["prompt"] or "'this'" in q["prompt"]:
            q["difficulty"] = "hard"

    pools["reading-tajweed|1"] = l1
    pools["reading-tajweed|2"] = l2
    pools["reading-tajweed|3"] = l3
    return pools

# ---------------------------------------------------------------- post-foundation
def curate_pf(pools):
    for lv in range(1, 7):
        key = f"advanced|{lv}"
        if key in pools:
            pools[key] = _rm(pools[key], lambda q: "does NOT belong" in q["prompt"],
                             "pf: odd-one-out (ambiguity risk)")
    return pools

def apply(pools):
    pools = curate_memorization(pools)
    pools = curate_foundation(pools)
    pools = curate_rt(pools)
    pools = curate_pf(pools)
    print(f"[curate] removed {len(REPORT['removed'])} · moved {len(REPORT['moved'])} · "
          f"two-excerpt reformatted {REPORT['reformatted']} · missing-word added {REPORT['added']}")
    return pools
