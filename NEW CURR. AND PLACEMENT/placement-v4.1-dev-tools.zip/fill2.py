# -*- coding: utf-8 -*-
"""Replacement items authored for the curriculum-alignment review (v4.1):
pure reading-foundation items for Arabic Foundation, and letter/harakah
foundations for Reading & Tajweed L1. correct=0 here; the builder rotates."""

def q(prog, lvl, skill, diff, prompt, options, arabic=None, options_arabic=False):
    d = {"skill": skill, "difficulty": diff, "prompt": prompt,
         "options": options, "correct": 0, "points": 1,
         "_prog": prog, "_lvl": lvl, "_src": "new-v41"}
    if arabic: d["arabic"] = arabic
    if options_arabic: d["options_arabic"] = True
    return d

NEW2 = []

# ---------------- Reading & Tajweed L1: letter & harakah foundations -------
NEW2 += [
 q("reading-tajweed", 1, "Letter Sounds", "easy",
   "Which of these is the letter 'Baa'?",
   ["ب", "ت", "ث", "ن"], options_arabic=True),
 q("reading-tajweed", 1, "Letter Sounds", "easy",
   "Which of these is the letter 'Qaaf'?",
   ["ق", "ف", "و", "ك"], options_arabic=True),
 q("reading-tajweed", 1, "Letter Sounds", "medium",
   "Which of these is the letter 'Daad'?",
   ["ض", "ص", "ط", "د"], options_arabic=True),
 q("reading-tajweed", 1, "Letters in Words", "medium",
   "Which of these shows the letter ع as it is written at the START of a word?",
   ["عـ", "ـعـ", "ـع", "ع"], options_arabic=True),
 q("reading-tajweed", 1, "Short Vowels", "easy",
   "How is this read?",
   ["sa", "si", "su", "s-baa"], arabic="سَ"),
 q("reading-tajweed", 1, "Short Vowels", "easy",
   "How is this read?",
   ["li", "la", "lu", "lee"], arabic="لِ"),
]

# ---------------- Foundation L1: letters, forms, harakat -------------------
NEW2 += [
 q("foundation", 1, "Letter Names", "easy",
   "Which of these is the letter 'Faa'?",
   ["ف", "ق", "غ", "ك"], options_arabic=True),
 q("foundation", 1, "Letter Names", "easy",
   "Which of these is the letter 'Haa' (the light one, as in 'house')?",
   ["ه", "ح", "خ", "ج"], options_arabic=True),
 q("foundation", 1, "Letter Shapes", "medium",
   "Which of these shows the letter ب as it is written in the MIDDLE of a word?",
   ["ـبـ", "بـ", "ـب", "ب"], options_arabic=True),
 q("foundation", 1, "Short Vowels", "easy",
   "How is this read?",
   ["ma", "mi", "mu", "maa"], arabic="مَ"),
]

# ---------------- Foundation L2: long vowels & closed syllables ------------
NEW2 += [
 q("foundation", 2, "Long Vowels", "medium",
   "Which word contains the long 'ee' sound (ya madd)?",
   ["كَبِير", "كَسْب", "كُتُب", "كَلْب"], options_arabic=True),
 q("foundation", 2, "Reading Syllables", "medium",
   "How is this read?",
   ["mus-lim", "mas-lam", "mu-sal-lim", "mis-lam"], arabic="مُسْلِم"),
 q("foundation", 2, "Reading Syllables", "medium",
   "Which word is read 'bint', with a resting ن?",
   ["بِنْت", "بِنَت", "بَنْت", "بُنْت"], options_arabic=True),
 q("foundation", 2, "Long Vowels", "medium",
   "In مushaf-style print, the small dagger alif ( ٰ ) over a letter is read as:".replace("مushaf", "mushaf"),
   ["a long 'aa'", "a short 'a'", "a doubled letter", "a silent letter"]),
 q("foundation", 2, "Reading Syllables", "easy",
   "Which of these is read 'qul' — one closed syllable?",
   ["قُلْ", "قُلُ", "قَلْ", "قِيل"], options_arabic=True),
 q("foundation", 2, "Reading Syllables", "medium",
   "How is this read?",
   ["yak-tu-bu", "ya-ka-ta-ba", "yuk-ti-bu", "yak-ta-ba"], arabic="يَكْتُبُ"),
]

# ---------------- Foundation L3: tanwin, shaddah, sun/moon, decoding -------
NEW2 += [
 q("foundation", 3, "Shaddah & Sukoon", "medium",
   "Which word is read 'rabbun', with a doubled 'b'?",
   ["رَبٌّ", "رَبٌ", "رَابٌ", "رُبٌّ"], options_arabic=True),
 q("foundation", 3, "Shaddah & Sukoon", "medium",
   "In الشَّمْس, how is the ل of الـ read?",
   ["not pronounced — the ش doubles instead", "pronounced clearly as an 'l' sound", "pronounced long, like a full 'aa'", "pronounced lightly, like an 'n'"]),
 q("foundation", 3, "Shaddah & Sukoon", "medium",
   "Which word is read 'ummun', with a doubled 'm'?",
   ["أُمٌّ", "أُمٌ", "أَمٌّ", "أُمَّا"], options_arabic=True),
 q("foundation", 3, "Reading Syllables", "medium",
   "How is this read?",
   ["mu-ham-ma-dun", "mu-ha-ma-dun", "mu-ham-ma-din", "ma-ham-ma-dun"], arabic="مُحَمَّدٌ"),
 q("foundation", 3, "Tanween", "easy",
   "How does the word كِتَابٌ end when read aloud?",
   ["with '-un'", "with '-an'", "with '-in'", "with '-aa'"]),
 q("foundation", 3, "Shaddah & Sukoon", "medium",
   "Which word is read 'kullun'?",
   ["كُلٌّ", "كُلٌ", "كَلٌّ", "كِلٌّ"], options_arabic=True),
 q("foundation", 3, "Reading Syllables", "medium",
   "How is this read?",
   ["jan-nah", "ja-na-ha", "jin-nah", "jan-na-tan"], arabic="جَنَّة"),
 q("foundation", 3, "Shaddah & Sukoon", "hard",
   "Which word carries BOTH a shaddah and a tanwin?",
   ["حَقٌّ", "حَقٌ", "حَقَّ", "حَاقٌ"], options_arabic=True),
 q("foundation", 3, "Reading Syllables", "hard",
   "How is this read?",
   ["ya-ta-'al-la-mu", "ya-ta-'a-la-mu", "yat-'al-la-ma", "yu-ta-'al-li-mu"], arabic="يَتَعَلَّمُ"),
 q("foundation", 3, "Shaddah & Sukoon", "medium",
   "Which word is read 'sharrun'?",
   ["شَرٌّ", "شَرٌ", "شِرٌّ", "شَارٌ"], options_arabic=True),
 q("foundation", 3, "Shaddah & Sukoon", "medium",
   "In السَّلَام, the س is:",
   ["doubled, because it is a sun letter", "read once, with the ل clear", "silent at the start", "read with a long 'ee'"]),
 q("foundation", 3, "Tanween", "medium",
   "Which word is read 'marratan', ending with '-an'?",
   ["مَرَّةً", "مَرَّةٌ", "مَرَّةٍ", "مَرَةً"], options_arabic=True),
]

# ---------------- Foundation L4: fluency, hamzah & orthography -------------
NEW2 += [
 q("foundation", 4, "Spelling & Orthography", "medium",
   "Which spelling is correct for 'mu'min' (a believer)?",
   ["مُؤْمِن", "مُئْمِن", "مُأْمِن", "مُوءْمِن"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "medium",
   "Which spelling is correct for 'samaa' (sky)?",
   ["سَمَاء", "سَمَاؤ", "سَمَائ", "سَمَاى"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "hard",
   "Which spelling is correct for 'as'ilah' (questions)?",
   ["أَسْئِلَة", "أَسْأِلَة", "أَسْؤِلَة", "أَسْيِلَة"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "easy",
   "Which word ends with ta marbutah (ة)?",
   ["مَدِينَة", "كِتَابُه", "مِيَاه", "وَجْه"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "medium",
   "In mushaf-style print you may see الصَّلَوٰة. In standard spelling it is written:",
   ["الصَّلَاة", "الصَّلَوَة", "الصَّلَاوَة", "الصَّلَة"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "medium",
   "Which word ends with a plain ه (not ta marbutah)?",
   ["وَجْه", "شَجَرَة", "مَدْرَسَة", "سَبُّورَة"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "medium",
   "You hear 'thalaathah' (three). Which spelling is correct?",
   ["ثَلَاثَة", "تَلَاتَة", "ثَلَاسَة", "سَلَاثَة"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "easy",
   "You hear 'dhahaba' (he went). Which spelling is correct?",
   ["ذَهَبَ", "زَهَبَ", "دَهَبَ", "ظَهَبَ"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "medium",
   "Which is the correct written form of the word 'ala (on / over)?",
   ["عَلَى", "عَلَي", "عَلَا", "عَلَء"], options_arabic=True),
 q("foundation", 4, "Reading Fluency", "hard",
   "How is this read?",
   ["yas-tagh-fi-roo-na", "yas-ta-ghaf-ru-na", "yus-tagh-fa-roo-na", "yas-tagh-fi-ru-nan"], arabic="يَسْتَغْفِرُونَ"),
 q("foundation", 4, "Reading Fluency", "medium",
   "How is this read?",
   ["al-mus-li-moo-na", "al-mas-la-moo-na", "il-mus-li-ma-na", "al-mus-lim-na"], arabic="الْمُسْلِمُونَ"),
 q("foundation", 4, "Reading Fluency", "medium",
   "When وَالْكِتَاب is read in one connected flow, the hamzah of الْـ is:",
   ["dropped — you read 'wal-kitab'", "pronounced clearly as 'a'", "held long for two counts", "doubled with a shaddah"]),
 q("foundation", 4, "Reading Fluency", "easy",
   "How is this read?",
   ["al-ham-du", "a-ha-ma-du", "al-hum-di", "il-ham-da"], arabic="الْحَمْدُ"),
]

def by_program():
    out = {}
    for item in NEW2:
        out.setdefault((item["_prog"], item["_lvl"]), []).append(item)
    return out
