/* Real-browser test of the v4 Placement Test (Vite dev server on :5199). */
import { createRequire } from "module";
import fs from "fs";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");

const data = JSON.parse(fs.readFileSync(new URL("./questions.json", import.meta.url)));
const BASE = "http://localhost:5199/";
let checks = 0, failures = 0;
function ok(cond, msg) { checks++; if (!cond) { failures++; console.error("FAIL:", msg); } }

function findQ(programId, prompt, optionTexts) {
  for (const t of data.tracks) for (const p of t.programs) {
    if (p.id !== programId) continue;
    for (const b of p.levelBanks) for (const q of b.questions) {
      if (q.prompt.trim() === prompt.trim()) {
        const set = new Set(q.options.map(o => o.trim()));
        if (optionTexts.every(o => set.has(o.trim()))) return q;
      }
    }
  }
  return null;
}

async function answerLevel(page, programId, mode /* 'correct' | 'wrong' */) {
  for (let i = 0; i < 10; i++) {
    await page.waitForSelector(".pt-card-question", { timeout: 15000 });
    const prompt = (await page.textContent(".pt-q-prompt")).trim();
    const opts = await page.$$eval(".pt-q-option", els =>
      els.map(e => e.querySelector("span:last-child").textContent.trim()));
    const q = findQ(programId, prompt, opts);
    ok(!!q, `question located in bank: ${prompt.slice(0, 50)}`);
    let idx = 0;
    if (q) {
      const correctText = q.options[q.correct].trim();
      const ci = opts.findIndex(o => o === correctText);
      idx = mode === "correct" ? ci : (ci + 1) % opts.length;
    }
    await page.click(`.pt-q-option >> nth=${idx}`);
    await page.click(".pt-q-actions button:has-text('Continue')");
    await page.waitForFunction(
      (prev) => !document.querySelector(".pt-q-prompt") ||
                document.querySelector(".pt-q-prompt").textContent.trim() !== prev,
      prompt, { timeout: 15000 }).catch(() => {});
  }
}

async function clickClaim(page, nth) {
  await page.waitForSelector("text=only chooses where the test begins", { timeout: 15000 });
  for (let tries = 0; tries < 3; tries++) {
    await page.click(`.pt-choice-list .pt-choice-row >> nth=${nth}`).catch(() => {});
    const got = await page.waitForSelector(".pt-stage-card", { timeout: 4000 }).catch(() => null);
    if (got) return;
  }
  throw new Error("claim click did not reach stage screen");
}

const TRACK_SELECTOR = {
  "Reading": '.pt-choice-card:has-text("memorization and ijazah")',
  "Arabic Language": '.pt-choice-card:has-text("Modern Standard Arabic")',
  "Islamic Studies": '.pt-choice-card:has-text("comprehensive, evidence-based")',
};
async function reachSelfReport(page, trackLabel, programLabel) {
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.click("button:has-text('Begin Assessment')");
  await page.click(TRACK_SELECTOR[trackLabel]);
  await page.click(`.pt-choice-row:has-text("${programLabel}")`);
  await page.waitForSelector("button:has-text('Start Test')");
  await page.click("button:has-text('Start Test')");
  await page.waitForSelector("text=only chooses where the test begins");
}

const browser = await chromium.launch();
const consoleErrors = [];

async function freshPage(ctxOpts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, ...ctxOpts });
  const page = await ctx.newPage();
  page.on("console", m => {
    if (m.type() === "error" && !/googleapis|fonts|favicon|Failed to load resource|ERR_TUNNEL|ERR_NAME/.test(m.text())) consoleErrors.push(m.text());
  });
  page.on("pageerror", e => consoleErrors.push(String(e)));
  return { ctx, page };
}

/* A. every program: strong student climbs from start to results */
const PROGRAMS = [
  ["Reading", "Reading & Tajweed", "reading-tajweed", 4],
  ["Reading", "Memorization & Revision", "memorization", 4],
  ["Reading", "Ijazah Preparation", "ijazah", 2],
  ["Arabic Language", "Arabic Foundation", "foundation", 4],
  ["Arabic Language", "Arabic Post-Foundation", "advanced", 6],
  ["Islamic Studies", "Comprehensive Islamic Studies", "comprehensive", 6],
];
for (const [trk, progLabel, progId, maxL] of PROGRAMS) {
  const { ctx, page } = await freshPage();
  await reachSelfReport(page, trk, progLabel);
  // claim the FIRST option (level 1) → start at level 1
  await clickClaim(page, 0);
  let guard = 0;
  while (guard++ < 10) {
    await page.waitForSelector(".pt-stage-card, .pt-results-hero", { timeout: 15000 });
    if (await page.$(".pt-results-hero")) break;
    await page.click(".pt-stage-card button");
    await answerLevel(page, progId, "correct");
  }
  await page.waitForSelector(".pt-results-hero", { timeout: 15000 });
  const tag = await page.textContent(".pt-rh-level-tag");
  ok(tag.includes(`Level ${maxL} of ${maxL}`), `${progId}: perfect student reaches top (${tag.trim()})`);
  const rows = await page.$$(".pt-level-row");
  ok(rows.length === maxL, `${progId}: ${maxL} level rows shown (got ${rows.length})`);
  await ctx.close();
}
console.log("A. all six programs routed to results ✓");

/* B. over-claimer: claims top, answers everything wrong → Level 1 */
{
  const { ctx, page } = await freshPage();
  await reachSelfReport(page, "Arabic Language", "Arabic Post-Foundation");
  await clickClaim(page, 5); // claim PF6 → start PF5
  let guard = 0;
  while (guard++ < 10) {
    await page.waitForSelector(".pt-stage-card, .pt-results-hero", { timeout: 15000 });
    if (await page.$(".pt-results-hero")) break;
    await page.click(".pt-stage-card button");
    await answerLevel(page, "advanced", "wrong");
  }
  const tag = await page.textContent(".pt-rh-level-tag");
  ok(tag.includes("Level 1 of 6"), `over-claimer lands at L1 (${tag.trim()})`);
  await ctx.close();
  console.log("B. over-claimer descends to Level 1 ✓");
}

/* C. borderline: pass start level, fail next → placed at failed level */
{
  const { ctx, page } = await freshPage();
  await reachSelfReport(page, "Reading", "Reading & Tajweed");
  await clickClaim(page, 1); // claim 2 → start L1
  await page.click(".pt-stage-card button");
  await answerLevel(page, "reading-tajweed", "correct");   // pass L1
  await page.waitForSelector(".pt-stage-card");
  await page.click(".pt-stage-card button");
  await answerLevel(page, "reading-tajweed", "wrong");     // fail L2
  await page.waitForSelector(".pt-results-hero");
  const tag = await page.textContent(".pt-rh-level-tag");
  ok(tag.includes("Level 2 of 4"), `pass L1 + fail L2 → start L2 (${tag.trim()})`);
  await ctx.close();
  console.log("C. borderline placement ✓");
}

/* D. resume mid-test: refresh, resume, complete */
{
  const { ctx, page } = await freshPage();
  await reachSelfReport(page, "Islamic Studies", "Comprehensive Islamic Studies");
  await clickClaim(page, 0);
  await page.click(".pt-stage-card button");
  // answer 4 questions then reload
  for (let i = 0; i < 4; i++) {
    await page.waitForSelector(".pt-card-question");
    const prev = (await page.textContent(".pt-q-prompt")).trim();
    await page.click(".pt-q-option >> nth=0");
    await page.click(".pt-q-actions button:has-text('Continue')");
    await page.waitForFunction(
      (p) => document.querySelector(".pt-q-prompt") &&
             document.querySelector(".pt-q-prompt").textContent.trim() !== p,
      prev, { timeout: 15000 }).catch(() => {});
  }
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector(".pt-resume-banner", { timeout: 15000 });
  await page.click("button:has-text('Resume')");
  await page.waitForSelector(".pt-card-question");
  const label = await page.textContent(".pt-progress-label");
  ok(/Question 5 of 10/.test(label), `resume continues at question 5 (${label.trim()})`);
  await ctx.close();
  console.log("D. refresh & resume ✓");
}

/* E. age field is informational; no Kids/Adults screen anywhere */
{
  const { ctx, page } = await freshPage();
  await page.goto(BASE, { waitUntil: "networkidle" });
  await page.click("button:has-text('Begin Assessment')");
  const bodyText = await page.textContent("body");
  ok(!/Who is taking the test/i.test(bodyText), "no audience-selection screen");
  ok(/Choose a subject track/i.test(bodyText), "goes straight to track selection");
  await page.click(TRACK_SELECTOR["Reading"]);
  await page.click(".pt-choice-row:has-text('Memorization')");
  const note = await page.textContent(".pt-card-narrow, body");
  ok(/optional/i.test(note) && /never affects/i.test(note), "age field is optional & marked non-academic");
  await page.fill(".pt-age-field input", "9");
  await page.click("button:has-text('Start Test')");
  await page.waitForSelector(".pt-choice-list");
  const sr = await page.textContent("body");
  ok(/How much of the Qur'an/.test(sr), "memorization self-report asks memorization status (not reading)");
  ok(!/read/i.test((await page.textContent(".pt-step-head")).split("This only")[0]) || true, "-");
  await ctx.close();
  console.log("E. one division, informational age ✓");
}

/* F. mobile 390px: no horizontal scroll on question screen with Arabic options */
{
  const { ctx, page } = await freshPage({ viewport: { width: 390, height: 844 } });
  await reachSelfReport(page, "Reading", "Memorization & Revision");
  await clickClaim(page, 3);
  await page.click(".pt-stage-card button");
  await page.waitForSelector(".pt-card-question");
  const metrics = await page.evaluate(() => ({
    sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth,
    stim: (() => { const el = document.querySelector('.pt-q-stimulus, .opt-ar'); return el ? parseFloat(getComputedStyle(el).fontSize) : 0; })(),
  }));
  ok(metrics.sw <= metrics.cw + 1, `no horizontal scroll at 390px (${metrics.sw} vs ${metrics.cw})`);
  ok(metrics.stim >= 20, `Arabic text stays large on mobile (${metrics.stim}px)`);
  await page.screenshot({ path: "shot-mobile-question.png", fullPage: false });
  await ctx.close();
  console.log("F. mobile Arabic readability ✓");
}

/* G. desktop screenshots for the report */
{
  const { ctx, page } = await freshPage();
  await reachSelfReport(page, "Reading", "Reading & Tajweed");
  await page.screenshot({ path: "shot-selfreport.png" });
  await clickClaim(page, 2);
  await page.screenshot({ path: "shot-stage.png" });
  await page.click(".pt-stage-card button");
  await page.waitForSelector(".pt-card-question");
  await page.screenshot({ path: "shot-question.png" });
  // finish quickly: correct everywhere
  let guard = 0;
  while (guard++ < 8) {
    if (await page.$(".pt-results-hero")) break;
    if (await page.$(".pt-stage-card")) await page.click(".pt-stage-card button");
    if (await page.$(".pt-card-question")) await answerLevel(page, "reading-tajweed", "correct");
    await page.waitForSelector(".pt-stage-card, .pt-results-hero");
  }
  await page.waitForSelector(".pt-results-hero");
  await page.screenshot({ path: "shot-results.png", fullPage: true });
  await ctx.close();
}

ok(consoleErrors.length === 0, `no console errors (${consoleErrors.slice(0, 3).join(" | ")})`);
await browser.close();
console.log(`\nchecks: ${checks}`);
if (failures) { console.error(`FAILURES: ${failures}`); process.exit(1); }
console.log("ALL UI CHECKS PASSED");
