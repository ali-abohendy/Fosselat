# -*- coding: utf-8 -*-
"""Remaps the v3 question banks (two divisions, old level structures) onto the
NEW Curriculum Framework (one Student Division):
  Quran:  reading-tajweed 4 · memorization 4 · ijazah 2
  Arabic: foundation 4 · post-foundation 6
  Islamic Studies: comprehensive 6 (specialized programs folded in or dropped)

Outputs remapped.json (draft pools per program/level) + a coverage report and
a list of low-confidence classifications for manual override.
"""
import json, re, sys, collections

sys.path.insert(0, "/home/claude/fosselat")
import quran_items as QI  # corpus access: surah(n) verses, clean_text

D = json.load(open("v3.json"))

# ---------------------------------------------------------------- helpers
def norm(s):
    return re.sub(r"\s+", " ", (s or "")).strip().lower()

def key_of(q):
    return (norm(q["prompt"]), norm(q.get("arabic")), tuple(sorted(norm(o) for o in q["options"])))

def text_of(q):
    return " ".join([q["prompt"]] + q["options"] + [q.get("arabic") or ""]).lower()

def iter_items(track, prog):
    for t in D["tracks"]:
        if t["id"] != track: continue
        for p in t["programs"]:
            if p["id"] != prog: continue
            for aud in ("kids", "adults"):
                for b in p["levelBanksByAudience"][aud]:
                    for q in b["questions"]:
                        yield aud, b["level"], q

def dedup(items):
    seen, out = set(), []
    for aud, lvl, q in items:
        k = key_of(q)
        if k in seen: continue
        seen.add(k)
        out.append((aud, lvl, q))
    return out

# ---------------------------------------------------------------- surah → juz
# start juz of each surah (approx; only used at surah granularity)
SURAH_JUZ = {}
_bounds = [  # (juz, first surah of that juz)
 (1,1),(2,2),(3,2),(4,3),(5,4),(6,4),(7,5),(8,6),(9,7),(10,8),(11,9),(12,11),
 (13,12),(14,15),(15,17),(16,18),(17,21),(18,23),(19,25),(20,27),(21,29),
 (22,33),(23,36),(24,39),(25,41),(26,46),(27,51),(28,58),(29,67),(30,78)]
for i in range(1, 115):
    jz = 1
    for j, s in _bounds:
        if i >= s: jz = j
    SURAH_JUZ[i] = jz

_SURAH_CLEAN = {}
def surah_clean(n):
    if n not in _SURAH_CLEAN:
        _SURAH_CLEAN[n] = QI.clean_text(" ".join(v["text"] for v in QI.verses(n)))
    return _SURAH_CLEAN[n]

def find_surah(fragment):
    """Locate a Qur'anic fragment; returns surah number or None."""
    frag = QI.clean_text(fragment or "").strip()
    frag = re.sub(r"\s+", " ", frag)
    if len(frag) < 12: return None
    probe = frag[:60]
    for n in range(1, 115):
        if probe in surah_clean(n):
            return n
    # fallback: first 30 chars
    probe = frag[:30]
    hits = [n for n in range(1, 115) if probe in surah_clean(n)]
    return hits[0] if len(hits) == 1 else None

def mem_level_for_surah(n):
    if n is None: return None
    if n in (36, 56, 18): return 2          # Yasin, Waqi'ah, Kahf core-surah bank
    jz = SURAH_JUZ[n]
    if jz == 30: return 1
    if jz == 29: return 2
    if jz >= 15: return 3                   # the 15 additional juz (≈15–28)
    return 4                                # early long surahs → complete-hifz band

# ---------------------------------------------------------------- rule tables
def matches(t, *words):
    return any(w in t for w in words)

def classify_rt(q, aud, lvl):
    t = text_of(q)
    s = q["skill"]
    if s in ("Similar Letters", "Letter Sounds", "Letters in Words", "Reading Words", "Short Vowels"):
        return 1
    if s in ("Long Vowels", "Tanween"):
        return 2
    if s == "Sukoon & Shaddah":
        return 3
    if s in ("Noon Rules", "Qalqalah", "Meem Rules", "Reading Accuracy"):
        return 3
    if s == "Stopping & Starting":
        return 4 if matches(t, "sign", "علامة", "symbol", "restart", "ibtida") else 3
    if s in ("Madd", "Madd Types"):
        if matches(t, "lazim", "لازم", "six count", "6 count"): return 3
        if matches(t, "strongest", "rank", "muqatta", "opening letters", "الم", "which type", "classified", "called"):
            return 4 if s == "Madd Types" else 2
        return 2
    if s == "Tajweed Rules":
        return 4
    if s == "Tajweed in Context":
        if matches(t, "muttasil", "متصل", "connected madd"): return 2
        if matches(t, "munfasil", "منفصل", "separate"): return 2
        if matches(t, "qalqalah", "قلقلة", "iqlab", "إقلاب", "sun letter", "الشمسية", "assimilat",
                   "ikhfa", "إخفاء", "izhar", "إظهار", "idgham", "إدغام", "ghunnah", "غنة",
                   "moon letter", "القمرية", "hidden nasal"):
            return 3
        return 3
    return None

def classify_foundation(q, aud, lvl):
    t = text_of(q)
    s = q["skill"]
    if s in ("Letter Names", "Letter Shapes", "Letter Sounds", "Alphabet Order", "Letters in Words", "Short Vowels"):
        return 1
    if s == "Reading Syllables":
        return 2 if matches(t, "sukoon", "سكون", "ْ") else 1
    if s == "Long Vowels":
        return 2
    if s == "Shaddah & Sukoon":
        return 3 if matches(t, "shaddah", "شدة", "ّ", "doubl") else 2
    if s == "Tanween":
        return 3
    if s == "Word Reading":
        return 2
    if s in ("Vocabulary", "Word Groups"):
        return 3
    if s in ("Sentences", "Words in Context"):
        return 4
    if s == "Everyday Arabic":
        return ("advanced", 1)   # migrates to Post-Foundation PF1
    return None

def classify_pf(q, aud, lvl):
    t = text_of(q)
    s = q["skill"]
    if s == "Vocabulary":
        if matches(t, "busy", "difficult", "tomorrow"): return 2
        return 1
    if s == "Conversation":
        if matches(t, "أعتذر", "apolog"): return 2
        return 1
    if s == "Verbs":
        if matches(t, "command", "أمر"): return 2
        if matches(t, "past tense conjugated", "we studied", "he ate"): return 2
        if matches(t, "future"): return 2
        if matches(t, "i am reading", "they (masculine) write"): return 2
        return 2
    if s == "Sentence Formation":
        return 3
    if s == "Nouns & Adjectives":
        return 3
    if s == "Grammar":
        if matches(t, "object", "comparative", "passive"): return 4
        return 3
    if s == "Reading Comprehension":
        return 4 if q["difficulty"] == "hard" else 3
    if s == "Advanced Reading":
        return 5
    if s == "Expression":
        if matches(t, "formal", "من ناحية"): return 6
        return 4
    if s == "Advanced Grammar":
        if matches(t, "passive", "conditional", "masdar"): return 5
        if matches(t, "الَّذِي", "relative", "obligation"): return 6
        return 5
    return None

def classify_ijazah(q, aud, lvl):
    return lvl  # unchanged program; structure already 2 levels

DROP = "DROP"

def classify_is(q, src_prog, aud, lvl):
    t = text_of(q)
    s = q["skill"]

    # ---- out-of-curriculum sciences → DROP (reserved for future specialized programs)
    if matches(t, "isnad", "matn", "mutawatir", "ahad ", "sahih", "hasan", "da'if", "daif",
               "asbab al-nuzul", "asbab an-nuzul", "makki", "madani", "abrogat",
               "usul", "maqasid", "madhhab", "ijtihad", "qiyas", "ijma"):
        # keep compiler/collection heritage items even if they mention sahih etc.
        if matches(t, "compil", "collection", "six books", "bukhari", "muslim") and not matches(t, "grade", "grading", "isnad", "matn"):
            return 4
        return DROP
    if s in ("Isnad and Matn", "Hadith Grading", "Applying Grades", "Mutawatir and Ahad",
             "Grading Hadith", "Methods of Tafsir", "Asbab al-Nuzul", "Makki & Madani",
             "Usul & Sources", "Maqasid", "Fiqh Concepts", "Applied Tafsir", "Qur'anic Sciences",
             "What is Tafsir", "Revelation Basics", "Revelation Context", "Lessons from Stories"):
        # salvage: surah-name / heritage / revelation-story items
        if matches(t, "names of the qur", "how many surahs", "order"): return 4
        if matches(t, "hira", "first revelation", "jibreel came", "iqra", "اقرأ"): return 5
        return DROP
    if s in ("Fiqh & Zakah", "Zakah", "Fasting", "Halal Earnings", "Travel and Illness", "Rulings (Ahkam)"):
        # pillar-concept items stay in L2; detailed rulings drop
        if matches(t, "pillar", "third pillar", "fourth pillar", "fifth pillar", "ramadan", "what is zakah", "what is sawm", "what does zakah mean", "what does sawm mean"):
            return 2
        if matches(t, "earn", "haram income", "riba"): return DROP
        return DROP

    # ---- purification & prayer
    if s in ("Wudu", "Purity"):
        if matches(t, "break", "nullif", "invalidate", "does not"): return 4
        return 3
    if s == "Tayammum": return 4
    if s == "Salah":
        if matches(t, "pillar", "five daily", "how many prayers", "second pillar"): return 2
        if matches(t, "adhan", "iqamah", "rak", "position", "sujud", "ruku", "takbir", "condition", "term"):
            return 5
        return 5
    if s == "Worship Basics": return 5
    if s == "Worship":
        if matches(t, "dua", "supplic", "tawakkul", "reli", "sacrifice", "vow", "oath", "refuge", "istighatha", "help"):
            return 5
        if matches(t, "pillar"): return 2
        return 5
    if s == "Prayer":
        if matches(t, "how many", "five", "pillar", "names of the"): return 2
        return 5

    # ---- creed
    if s in ("Belief", "Belief in Allah", "Foundations of Belief"):
        if matches(t, "three", "principle", "grave"): return 3
        if matches(t, "lord", "creator", "who is allah", "one god", "none like"): return 1
        return 2
    if s in ("Pillars of Iman", "Pillars & Basics", "Pillars & Practice"):
        return 2
    if s in ("Angels & Books", "Angels and Books"):
        if matches(t, "function", "duty", "jibreel", "mikail", "israfil", "malik", "ridwan", "izrail", "task"):
            return 3
        return 2
    if s == "Prophets":
        if matches(t, "resolute", "ulul", "azm", "five ", "25", "twenty-five"): return 3 if "resolute" in t or "azm" in t or "five" in t else 4
        return 2
    if s in ("Tawheed & Belief", "Categories of Tawheed"):
        return 4
    if s == "Tawheed & Qadar":
        if matches(t, "pen", "written", "destiny", "qadar"): return 4
        return 4
    if s in ("Names and Attributes",): return 6
    if s == "Shirk":
        if matches(t, "major", "minor", "amulet", "omen", "swear", "vow to", "invok", "riya", "show off"):
            return 6
        return 5
    if s in ("Last Day and Qadar", "Signs of the Hour"):
        if matches(t, "sign", "hour", "dajjal"): return DROP  # not in the 6-level syllabus
        if matches(t, "grave", "question"): return 3
        return 2
    if s in ("Qadar Applied", "Applied Aqeedah"):
        return 6

    # ---- seerah
    if s in ("Early Life",):
        return 5
    if s in ("Key Events", "Key People", "Migration", "Companions", "Seerah",
             "Dates & Sequence", "Dates & Timeline", "Battles", "Treaties & Covenants",
             "Farewell Sermon", "Lessons & Significance", "Historical Understanding"):
        if matches(t, "hira", "first revelation", "black stone", "rebuild", "khadijah support", "waraqah",
                   "before prophethood", "trustworthy", "al-amin"):
            return 5
        if matches(t, "persecut", "bilal", "sumayyah", "yasir", "abyssinia", "boycott", "grief",
                   "ta'if", "taif", "isra", "mi'raj", "miraj", "night journey", "abu talib died", "martyr"):
            return 6
        return 3

    # ---- hadith
    if s in ("Hadith Basics", "The Sunnah", "Famous Hadith", "Hadith Foundations", "Qur'an & Hadith"):
        if matches(t, "intention", "jibreel", "ihsan", "pillar"): return 2
        if matches(t, "tongue", "clean", "brother", "anger", "innovation", "bid'ah"): return 1
        if matches(t, "halal", "haram", "naseehah", "advice", "charity", "obey", "earnings"): return 3
        if matches(t, "doubt", "concern", "love for", "neighbor", "guest", "speak good", "silent"): return 4
        if matches(t, "modesty", "taqwa", "character", "virtue", "sin", "change", "evil"): return 5
        if matches(t, "steadfast", "inviolab", "purity", "half of faith", "oppress", "qudsi", "tasbih"): return 6
        return 2
    if s in ("Hadith Compilers", "Collections & Scholars", "The Six Books", "Hadith Collections", "Hadith Sciences"):
        if matches(t, "grade", "grading", "isnad", "chain", "authentic vs"): return DROP
        return 4

    # ---- tafsir / qur'an knowledge
    if s in ("Surah Themes", "Central Message", "Prophet & Qur'an", "Qur'an Sciences"):
        # theme items keyed to the memorization ladder of each level
        if matches(t, "fatiha", "ikhlas", "kawthar", "falaq", "nas ", "an-nas", "al-nas"): return 1
        if matches(t, "asr", "humazah", "feel", "fil", "quraysh", "ma'un", "maun", "kafirun", "nasr", "lahab", "masad"): return 2
        if matches(t, "kursi", "baqarah", "takathur", "qadr", "zalzalah", "bayyinah", "adiyat", "qari'ah"): return 3
        if matches(t, "layl", "duha", "sharh", "tin", "alaq", "shams"): return 5
        if matches(t, "a'la", "ghashiyah", "fajr", "balad"): return 6
        if matches(t, "names of the qur", "how many surahs", "juz", "order"): return 4
        return DROP if matches(t, "compil", "revelation over", "23 years") else 2
    if s == "Manners & Du'a": return 1
    if s == "Manners & Family": return 4

    # ---- manners / character
    if s in ("Eating & Drinking", "Kindness & Care"): return 1
    if s in ("Greetings & Speech", "Masjid Manners", "Home & Guests"): return 2
    if s == "Speech & Slander": return 4
    if s in ("Patience & Forgiveness",): return 5
    if s in ("Trust & Truthfulness", "Humility & Conduct"): return 6
    if s == "Character Terms": return 4
    if s == "Applying Character": return 6
    if s == "Parents & Family": return 6

    return None

# ---------------------------------------------------------------- run remap
POOLS = collections.defaultdict(list)   # (program, level) -> [q]
UNMATCHED, DROPPED = [], []

def place(prog, level, q, src):
    q = dict(q)
    q["_src"] = src
    POOLS[(prog, level)].append(q)

# Quran: reading-tajweed
for aud, lvl, q in dedup(iter_items("quran", "reading-tajweed")):
    lv = classify_rt(q, aud, lvl)
    if lv: place("reading-tajweed", lv, q, f"rt-{aud}{lvl}")
    else: UNMATCHED.append(("reading-tajweed", aud, lvl, q))

# Quran: memorization (corpus mapping)
mem_fallback = 0
for aud, lvl, q in dedup(iter_items("quran", "memorization")):
    frag = q.get("arabic") or ""
    n = find_surah(frag)
    if n is None and q.get("optionsArabic"):
        n = find_surah(q["options"][q["correct"]])
    lv = mem_level_for_surah(n)
    if lv is None:
        lv = lvl if aud == "kids" else min(lvl, 4)
        mem_fallback += 1
    place("memorization", lv, q, f"mem-{aud}{lvl}")

# Quran: ijazah (unchanged) + copy of advanced sets into RT L4
for aud, lvl, q in dedup(iter_items("quran", "ijazah")):
    place("ijazah", lvl, q, f"ij-{aud}{lvl}")
    if lvl == 1 and q["skill"] in ("Makharij & Sifaat", "Madd Precision", "Applied Rules"):
        place("reading-tajweed", 4, q, "ij-share")

# Arabic: foundation
for aud, lvl, q in dedup(iter_items("arabic", "foundation")):
    r = classify_foundation(q, aud, lvl)
    if r is None: UNMATCHED.append(("foundation", aud, lvl, q))
    elif isinstance(r, tuple): place(r[0], r[1], q, f"fnd-{aud}{lvl}")
    else: place("foundation", r, q, f"fnd-{aud}{lvl}")

# Arabic: post-foundation
for aud, lvl, q in dedup(iter_items("arabic", "advanced")):
    lv = classify_pf(q, aud, lvl)
    if lv: place("advanced", lv, q, f"pf-{aud}{lvl}")
    else: UNMATCHED.append(("advanced", aud, lvl, q))

# Islamic Studies: comprehensive + folded specialized programs
IS_PROGS = ["comprehensive", "aqeedah", "fiqh", "seerah", "hadith", "tafsir", "manners"]
seen_is = set()
for prog in IS_PROGS:
    for aud, lvl, q in dedup(iter_items("islamic-studies", prog)):
        k = key_of(q)
        if k in seen_is: continue
        seen_is.add(k)
        lv = classify_is(q, prog, aud, lvl)
        if lv == DROP: DROPPED.append((prog, aud, lvl, q))
        elif lv: place("comprehensive", lv, q, f"{prog}-{aud}{lvl}")
        else: UNMATCHED.append((f"is/{prog}", aud, lvl, q))

# ---------------------------------------------------------------- report
print("=== POOL SIZES (draft) ===")
STRUCT = {"reading-tajweed": 4, "memorization": 4, "ijazah": 2,
          "foundation": 4, "advanced": 6, "comprehensive": 6}
for prog, nlv in STRUCT.items():
    for lv in range(1, nlv + 1):
        pool = POOLS.get((prog, lv), [])
        diffs = collections.Counter(q["difficulty"] for q in pool)
        skills = collections.Counter(q["skill"] for q in pool)
        flag = "  << LOW" if len(pool) < 16 else ""
        print(f"{prog:<16} L{lv}: {len(pool):>3}  e/m/h={diffs.get('easy',0)}/{diffs.get('medium',0)}/{diffs.get('hard',0)}{flag}")
        top = ", ".join(f"{s}:{c}" for s, c in skills.most_common(6))
        print(f"                  {top}")
print(f"\nmem corpus-fallback items: {mem_fallback}")
print(f"dropped (out of curriculum): {len(DROPPED)}")
print(f"unmatched: {len(UNMATCHED)}")
for src, aud, lvl, q in UNMATCHED[:40]:
    print(f"  ? {src} {aud}{lvl} [{q['skill']}] {q['prompt'][:80]}")

json.dump({f"{p}|{l}": [dict(q) for q in v] for (p, l), v in POOLS.items()},
          open("remapped.json", "w"), ensure_ascii=False, indent=1)
print("\nwrote remapped.json")
PY_END = True
