# -*- coding: utf-8 -*-
"""Newly authored items that fill coverage gaps created by the new framework
(one division, Post-Foundation split to 6 levels, Islamic Studies folded to a
single 6-level Comprehensive program). Format matches the remapped v3 items:
correct is always index 0 here; the builder rotates option order."""

def q(prog, lvl, skill, diff, prompt, options, arabic=None, options_arabic=False):
    d = {"skill": skill, "difficulty": diff, "prompt": prompt,
         "options": options, "correct": 0, "points": 1,
         "_prog": prog, "_lvl": lvl, "_src": "new"}
    if arabic: d["arabic"] = arabic
    if options_arabic: d["options_arabic"] = True
    return d

NEW = []

# ============================ READING & TAJWEED ============================
# L2 easy band (elongation & tanwin at reading level)
NEW += [
 q("reading-tajweed", 2, "Long Vowels", "easy",
   "Which word contains the long 'ee' sound (ya madd)?",
   ["قِيلَ", "قَبْلَ", "قُلْ", "قَلْبَ"], options_arabic=True),
 q("reading-tajweed", 2, "Madd", "easy",
   "A natural madd — like the 'aa' in قَالَ — is held for:",
   ["2 counts", "4 counts", "6 counts", "8 counts"]),
 q("reading-tajweed", 2, "Tanween", "easy",
   "Which of these words carries tanwin?",
   ["كِتَابٌ", "الْكِتَابُ", "كِتَابُكَ", "كُتُبَهُمْ"], options_arabic=True),
 q("reading-tajweed", 2, "Long Vowels", "easy",
   "The small round circle placed above a letter in the mushaf (the round zero) tells you the letter is:",
   ["not pronounced at all", "doubled and stressed", "elongated six counts", "nasalized with ghunnah"]),
]
# L4 depth (waqf signs, ra/lam, sakt, ranking, speeds)
NEW += [
 q("reading-tajweed", 4, "Stopping & Starting", "medium",
   "The stop sign مـ written above a word in the mushaf means:",
   ["you must stop here", "you must keep reading", "stopping is disliked here", "repeat the previous word"]),
 q("reading-tajweed", 4, "Stopping & Starting", "medium",
   "The sign لا written above a word in the mushaf means:",
   ["do not stop here", "you must stop here", "pause without breathing", "prostrate after this word"]),
 q("reading-tajweed", 4, "Applied Rules", "hard",
   "A small ســ above the text marks a sakt. What is a sakt?",
   ["a brief pause without taking a new breath", "a full stop with a new breath", "a six-count obligatory elongation", "a doubled nasal sound"]),
 q("reading-tajweed", 4, "Tajweed Rules", "hard",
   "When is the letter ر pronounced light (tarqiq)?",
   ["when it carries a kasra", "when it carries a fatha", "when it carries a damma", "in every case, always"]),
 q("reading-tajweed", 4, "Tajweed Rules", "hard",
   "The lam of the Divine Name (اللَّه) is pronounced heavy (tafkhim) when:",
   ["the sound before it is a fatha or damma", "the sound before it is a kasra", "it appears in the middle of any word", "the reciter chooses to emphasize it"]),
 q("reading-tajweed", 4, "Madd Types", "hard",
   "Which of these madd types is the strongest, held the longest?",
   ["madd lazim", "madd tabee'i", "madd munfasil", "madd 'iwad"]),
 q("reading-tajweed", 4, "Applied Rules", "medium",
   "The opening letters الم at the start of a surah are recited by:",
   ["naming each letter with its own madd", "joining them as one word 'alam'", "reading them silently in the heart", "replacing them with a basmalah"]),
 q("reading-tajweed", 4, "Tajweed Rules", "hard",
   "Which recitation pace is the slow, deliberate one used for teaching and precision?",
   ["tahqeeq", "hadr", "tadweer", "takrar"]),
]

# ============================ ARABIC FOUNDATION ============================
# F2: long vowels & closed syllables
NEW += [
 q("foundation", 2, "Long Vowels", "easy",
   "Which word contains a long alif (the 'aa' sound)?",
   ["كِتَاب", "كَتَبَ", "كُتُب", "كَتْب"], options_arabic=True),
 q("foundation", 2, "Long Vowels", "easy",
   "Which word contains the long 'oo' sound (waw madd)?",
   ["سُوق", "سَبَق", "سirr".replace("irr","ِرّ"), "سَقْف"], options_arabic=True),
 q("foundation", 2, "Reading Syllables", "medium",
   "In the word يَبْدَأ, how is the بْ (with sukoon) read?",
   ["stopped short, with no vowel after it", "with a long 'aa' after it", "doubled and held longer", "as 'bi' with a short 'i'"]),
 q("foundation", 2, "Word Reading", "medium",
   "In which word is the ل of الْـ pronounced clearly (a moon letter)?",
   ["الْقَمَر", "الشَّمْس", "الرَّجُل", "السُّوق"], options_arabic=True),
 q("foundation", 2, "Word Reading", "medium",
   "Which word is read 'maktab' (office / desk)?",
   ["مَكْتَب", "مَكَتَب", "مُكْتِب", "مَكْتُوب"], options_arabic=True),
]
# F4: fluency, orthography & spelling foundations
NEW += [
 q("foundation", 4, "Spelling & Orthography", "medium",
   "Which spelling of the word for 'question' is correct?",
   ["سُؤَال", "سُءَال", "سُوَال", "سُأَال"], options_arabic=True),
 q("foundation", 4, "Spelling & Orthography", "hard",
   "In قَرَأَ the final hamzah is seated on an alif because:",
   ["the vowel before it is a fatha", "the word begins with a qaf", "the hamzah is silent there", "every verb ends with an alif"]),
 q("foundation", 4, "Spelling & Orthography", "medium",
   "A word may show a small dagger alif in mushaf-style print. In standard spelling the same long sound is written with:",
   ["a full alif letter", "a doubled consonant", "a final ta marbutah", "a small circle sign"]),
 q("foundation", 4, "Spelling & Orthography", "medium",
   "Which word ends with alif maqsurah (ى)?",
   ["مُوسَى", "سَمَاء", "دُعَاء", "بِنَاء"], options_arabic=True),
 q("foundation", 4, "Sentences", "hard",
   "Read the passage, then answer: when did Maryam return home?",
   ["Before sunset", "After the night prayer", "At noon exactly", "On the next morning"],
   arabic="ذَهَبَتْ مَرْيَمُ إِلَى الْمَكْتَبَةِ، وَقَرَأَتْ قِصَّةً جَمِيلَةً، ثُمَّ عَادَتْ إِلَى بَيْتِهَا قَبْلَ الْمَغْرِبِ."),
 q("foundation", 4, "Spelling & Orthography", "medium",
   "You hear the word 'madrasa' (school). Which spelling is correct?",
   ["مَدْرَسَة", "مَدْرَصَة", "مَضْرَسَة", "مَذْرَسَة"], options_arabic=True),
]

# ============================ POST-FOUNDATION ==============================
# PF2 — everyday transactions
NEW += [
 q("advanced", 2, "Transactions", "medium",
   "You want to ask a shopkeeper the price. Which question do you use?",
   ["بِكَمْ هَذَا الْكِتَابُ؟", "أَيْنَ هَذَا الْكِتَابُ؟", "لِمَنْ هَذَا الْكِتَابُ؟", "مَتَى وَصَلَ الْكِتَابُ؟"], options_arabic=True),
 q("advanced", 2, "Transactions", "easy",
   "What does this sentence mean?",
   ["The weather is hot in summer", "The weather is cold in winter", "The weather is mild in spring", "The weather is rainy in autumn"],
   arabic="الْجَوُّ حَارٌّ فِي الصَّيْفِ."),
 q("advanced", 2, "Travel", "medium",
   "You are at the airport and your bag is missing. Which sentence do you say?",
   ["فَقَدْتُ حَقِيبَتِي", "حَجَزْتُ تَذْكِرَتِي", "وَجَدْتُ جَوَازِي", "أَكَّدْتُ رِحْلَتِي"], options_arabic=True),
 q("advanced", 2, "Health", "easy",
   "Someone says: عِنْدِي صُدَاعٌ شَدِيدٌ. What are they suffering from?",
   ["A bad headache", "A high fever", "A stomach ache", "A broken arm"]),
 q("advanced", 2, "Numbers", "hard",
   "Which is the correct way to say 25 (for counting)?",
   ["خَمْسَةٌ وَعِشْرُونَ", "عِشْرُونَ وَخَمْسَةٌ", "خَمْسَةَ عَشَرَ", "خَمْسُونَ وَخَمْسَةٌ"], options_arabic=True),
 q("advanced", 2, "Verbs", "medium",
   "Which sentence means 'I saw him yesterday'?",
   ["رَأَيْتُهُ أَمْسِ", "رَأَيْتُهَا أَمْسِ", "رَأَيْتُكَ أَمْسِ", "رَأَيْتُهُمْ أَمْسِ"], options_arabic=True),
 q("advanced", 2, "Verbs", "medium",
   "A doctor tells the patient to drink water. Which form does the doctor use?",
   ["اِشْرَبِ الْمَاءَ", "شَرِبَ الْمَاءَ", "يَشْرَبُ الْمَاءَ", "شُرْبُ الْمَاءِ"], options_arabic=True),
 q("advanced", 2, "Vocabulary", "medium",
   "What does the word الطَّوَاف refer to?",
   ["Walking around the Ka'bah", "Standing on mount Arafah", "Walking between Safa and Marwah", "Throwing the small pebbles"]),
]
# PF4 — connected discourse & case/mood essentials
NEW += [
 q("advanced", 4, "Grammar", "hard",
   "In لَنْ أُسَافِرَ غَدًا, why does the verb end with a fatha (أُسَافِرَ)?",
   ["because لَنْ puts the present verb in nasb", "because the verb refers to the past", "because غَدًا always demands a fatha", "because the speaker is one person"]),
 q("advanced", 4, "Grammar", "hard",
   "Which sentence contains a jussive (majzum) verb?",
   ["لَمْ يَكْتُبْ الطَّالِبُ الدَّرْسَ", "يَكْتُبُ الطَّالِبُ الدَّرْسَ", "لَنْ يَكْتُبَ الطَّالِبُ الدَّرْسَ", "كَتَبَ الطَّالِبُ الدَّرْسَ"], options_arabic=True),
 q("advanced", 4, "Grammar", "medium",
   "Which phrase pairs the number with its counted noun correctly?",
   ["ثَلَاثَةُ كُتُبٍ", "ثَلَاثَةُ كِتَابٍ", "ثَلَاثُ كُتُبٍ", "ثَلَاثُ كِتَابٍ"], options_arabic=True),
 q("advanced", 4, "Reading Comprehension", "hard",
   "Read the announcement, then answer: what is it about?",
   ["Building new schools next year", "Closing three old schools", "Hiring new teachers this term", "Opening a new hospital wing"],
   arabic="أَعْلَنَتِ الْوِزَارَةُ عَنْ بِنَاءِ ثَلَاثِ مَدَارِسَ جَدِيدَةٍ فِي الْمَدِينَةِ الْعَامَ الْقَادِمَ."),
 q("advanced", 4, "Expression", "medium",
   "Which phrase introduces your own opinion?",
   ["فِي رَأْيِي", "فِي بَيْتِي", "فِي طَرِيقِي", "فِي مَدِينَتِي"], options_arabic=True),
 q("advanced", 4, "Grammar", "hard",
   "In جَاءَ الطَّالِبُ, the word الطَّالِبُ is:",
   ["the subject (fa'il), in raf'", "the object (maf'ul), in nasb", "a possessed noun, in jarr", "an adverb of time, in nasb"]),
]
# PF5 — extended reading & structural depth
NEW += [
 q("advanced", 5, "Advanced Grammar", "medium",
   "What does this sentence mean?",
   ["If you study, you will succeed", "When he studied, he succeeded", "Study, then you succeeded", "He studies and then succeeds"],
   arabic="إِنْ تَدْرُسْ تَنْجَحْ."),
 q("advanced", 5, "Advanced Grammar", "medium",
   "Which sentence is in the passive voice?",
   ["كُتِبَ الدَّرْسُ أَمْسِ", "كَتَبَ الطَّالِبُ الدَّرْسَ", "يَكْتُبُ الطَّالِبُ الدَّرْسَ", "اُكْتُبْ دَرْسَكَ الْآنَ"], options_arabic=True),
 q("advanced", 5, "Morphology", "medium",
   "Which word is an active participle (اسم فاعل)?",
   ["كَاتِب", "مَكْتُوب", "كِتَابَة", "مَكْتَب"], options_arabic=True),
 q("advanced", 5, "Morphology", "medium",
   "Which word is a passive participle (اسم مفعول)?",
   ["مَفْهُوم", "فَاهِم", "فَهْم", "تَفْهِيم"], options_arabic=True),
 q("advanced", 5, "Morphology", "hard",
   "The verb اِسْتَخْرَجَ follows the pattern اِسْتَفْعَلَ. What meaning does this pattern usually add?",
   ["seeking or trying to obtain the action", "doing the action to one another", "slowly becoming the quality named", "doing the action a single time"]),
 q("advanced", 5, "Advanced Grammar", "hard",
   "Which sentence has two objects?",
   ["أَعْطَيْتُ الْفَقِيرَ طَعَامًا", "أَكَلَ الْوَلَدُ الطَّعَامَ", "نَامَ الطِّفْلُ مُبَكِّرًا", "جَلَسَ الضَّيْفُ فِي الْبَيْتِ"], options_arabic=True),
 q("advanced", 5, "Morphology", "hard",
   "Which of these nouns never takes tanwin (a diptote)?",
   ["مَسَاجِد", "بُيُوت", "كُتُب", "أَقْلَام"], options_arabic=True),
 q("advanced", 5, "Advanced Reading", "hard",
   "Read the passage, then answer: why did Omar leave his trade?",
   ["To devote himself to teaching children", "Because his trade was losing money", "To move to a larger nearby city", "Because his health became weak"],
   arabic="كَانَ عُمَرُ يَعْمَلُ فِي التِّجَارَةِ، فَلَمَّا كَبِرَ تَرَكَ الْعَمَلَ وَتَفَرَّغَ لِتَعْلِيمِ الصِّغَارِ فِي قَرْيَتِهِ دُونَ أَجْرٍ."),
]
# PF6 — academic readiness & composition
NEW += [
 q("advanced", 6, "Advanced Grammar", "hard",
   "Which sentence contains an absolute object (مفعول مطلق)?",
   ["فَرِحَ الطِّفْلُ فَرَحًا شَدِيدًا", "فَرِحَ الطِّفْلُ بِالْهَدِيَّةِ", "فَرِحَ الطِّفْلُ عِنْدَ أَبِيهِ", "الطِّفْلُ فَرِحٌ بِالْعِيدِ"], options_arabic=True),
 q("advanced", 6, "Advanced Grammar", "hard",
   "In جِئْتُ طَلَبًا لِلْعِلْمِ, the word طَلَبًا expresses:",
   ["the purpose of the action", "the time of the action", "the manner of the action", "the doer of the action"]),
 q("advanced", 6, "Advanced Grammar", "hard",
   "Which sentence contains a specification (تمييز)?",
   ["اِزْدَادَ الطَّالِبُ عِلْمًا", "عِلْمُ الطَّالِبِ وَاسِعٌ", "يَزْدَادُ الْعِلْمُ بِالْقِرَاءَةِ", "طَلَبُ الْعِلْمِ وَاجِبٌ"], options_arabic=True),
 q("advanced", 6, "Reading Comprehension", "medium",
   "What does حَضَرَ الطُّلَّابُ إِلَّا خَالِدًا mean?",
   ["All the students came except Khalid", "Only Khalid came to the lesson", "Khalid arrived after the students", "The students came with Khalid"]),
 q("advanced", 6, "Advanced Grammar", "hard",
   "Which sentence uses لا النافية للجنس correctly?",
   ["لَا طَالِبَ فِي الْفَصْلِ", "لَا الطَّالِبُ فِي الْفَصْلِ", "لَا طَالِبٌ فِي الْفَصْلِ", "لَا فِي الْفَصْلِ طَالِبَ"], options_arabic=True),
 q("advanced", 6, "Expression", "medium",
   "Which sentence states its point with the strongest emphasis?",
   ["إِنَّ الْعِلْمَ لَنُورٌ", "الْعِلْمُ نُورٌ", "الْعِلْمُ كَالنُّورِ", "رُبَّمَا كَانَ الْعِلْمُ نُورًا"], options_arabic=True),
 q("advanced", 6, "Advanced Grammar", "hard",
   "In يَسُرُّنِي حُضُورُكَ, the word حُضُورُكَ functions as:",
   ["a masdar serving as the subject", "a past verb with a pronoun", "an adjective describing the speaker", "a vocative form of address"]),
 q("advanced", 6, "Expression", "hard",
   "Fronting the object — الرِّسَالَةَ كَتَبَ خَالِدٌ instead of كَتَبَ خَالِدٌ الرِّسَالَةَ — mainly adds:",
   ["emphasis on what was written", "a question about the letter", "negation of the writing", "a shift from past to future"]),
 q("advanced", 6, "Advanced Reading", "hard",
   "What does this proverb mean?",
   ["Whoever strives seriously will succeed", "Whoever hurries will surely stumble", "Whoever is generous will be loved", "Whoever travels far learns much"],
   arabic="مَنْ جَدَّ وَجَدَ."),
 q("advanced", 6, "Advanced Reading", "hard",
   "What does this saying mean?",
   ["The best speech is brief and clear", "The best speech is long and detailed", "Speech is always better than silence", "Few people ever speak with wisdom"],
   arabic="خَيْرُ الْكَلَامِ مَا قَلَّ وَدَلَّ."),
 q("advanced", 6, "Expression", "hard",
   "Which sentence belongs to formal written Arabic rather than casual speech?",
   ["تَجْدُرُ الْإِشَارَةُ إِلَى أَهَمِّيَّةِ الْمَوْضُوعِ", "الْمَوْضُوع دَه مُهِمّ أَوِي بِصَرَاحَة يَعْنِي", "يَعْنِي الْمَوْضُوع دَه مُهِمّ جِدًّا وَاللهِ", "الْمَوْضُوع مُهِمّ خَالِص وَكُلّ النَّاس عَارْفَاه"], options_arabic=True),
 q("advanced", 6, "Expression", "medium",
   "Ahmad said: «أَنَا مَشْغُولٌ الْيَوْمَ». Which sentence reports his words correctly?",
   ["قَالَ أَحْمَدُ إِنَّهُ مَشْغُولٌ ذَلِكَ الْيَوْمَ", "قَالَ أَحْمَدُ أَنَا مَشْغُولٌ الْيَوْمَ", "قَالَ أَحْمَدُ كُنْ مَشْغُولًا الْيَوْمَ", "قَالَ أَحْمَدُ هَلْ أَنْتَ مَشْغُولٌ الْيَوْمَ"], options_arabic=True),
]

# ===================== ISLAMIC STUDIES — COMPREHENSIVE =====================
# L1 — first foundations
NEW += [
 q("comprehensive", 1, "Belief", "easy",
   "Who created the heavens, the earth, and everything in them?",
   ["Allah alone", "The angels together", "The first prophets", "The sun and stars"]),
 q("comprehensive", 1, "Belief", "easy",
   "Who is Muhammad ﷺ?",
   ["The final Messenger of Allah", "The first man Allah created", "An angel sent down to earth", "A king of ancient Makkah"]),
 q("comprehensive", 1, "Qur'an Knowledge", "easy",
   "Which surah comes first in the mushaf?",
   ["Al-Fatihah", "Al-Ikhlas", "An-Nas", "Al-Baqarah"]),
 q("comprehensive", 1, "Manners & Du'a", "medium",
   "When do you say بِسْمِ اللَّهِ؟",
   ["Before eating and before starting things", "Only after finishing your food", "Only when entering the masjid", "Only after sneezing loudly"]),
 q("comprehensive", 1, "Manners & Du'a", "medium",
   "What do you say when you sneeze?",
   ["الْحَمْدُ لِلَّهِ", "بِسْمِ اللَّهِ", "أَسْتَغْفِرُ اللَّهَ", "سُبْحَانَ اللَّهِ"], options_arabic=True),
 q("comprehensive", 1, "Qur'an Knowledge", "medium",
   "Which surah comes right after Al-Fatihah in the mushaf?",
   ["Al-Baqarah", "Al-Ikhlas", "An-Nas", "Yusuf"]),
]
# L5 — forms of worship & establishing the prayer
NEW += [
 q("comprehensive", 5, "Salah & Adhan", "medium",
   "When the mu'adhdhin says حَيَّ عَلَى الصَّلَاةِ, what do you reply?",
   ["لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "نَفْسُ الْكَلِمَاتِ كَمَا قَالَهَا", "الصَّلَاةُ خَيْرٌ مِنَ النَّوْمِ", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"], options_arabic=True),
 q("comprehensive", 5, "Salah & Adhan", "medium",
   "What is the iqamah?",
   ["The short call made right before the prayer begins", "The dawn call made from the minaret only", "A supplication recited after the prayer ends", "The opening words of the Friday sermon"]),
 q("comprehensive", 5, "Salah & Adhan", "medium",
   "How many rak'ahs is the Maghrib prayer?",
   ["Three", "Two", "Four", "Five"]),
 q("comprehensive", 5, "Salah & Adhan", "medium",
   "What is takbirat al-ihram?",
   ["The 'Allahu Akbar' that opens the prayer", "The bowing position of the prayer", "The closing salam of the prayer", "The sitting between the two prostrations"]),
 q("comprehensive", 5, "Forms of Worship", "hard",
   "A vow (nadhr) is an act of worship. To whom alone may a vow be made?",
   ["To Allah", "To Allah and His Prophets", "To any righteous person", "To one's own parents"]),
 q("comprehensive", 5, "Forms of Worship", "hard",
   "Sacrificing an animal as an act of worship may be offered:",
   ["only to Allah", "to Allah and to the awliya", "to the dead to seek their help", "to the jinn to gain protection"]),
]
# L6 — complete devotional practice & guarding tawheed
NEW += [
 q("comprehensive", 6, "Salah Completion", "hard",
   "How does the funeral (janazah) prayer differ from the other prayers?",
   ["It has no ruku' and no sujud", "It has extra prostrations added", "It is prayed while sitting down", "It is prayed without any takbir"]),
 q("comprehensive", 6, "Salah Completion", "medium",
   "How many takbirs are made in the janazah prayer?",
   ["Four", "Two", "Six", "Seven"]),
 q("comprehensive", 6, "Salah Completion", "medium",
   "In the well-known adhkar after each obligatory prayer, how many times is سُبْحَانَ اللَّهِ said?",
   ["33", "10", "100", "50"]),
 q("comprehensive", 6, "Salah Completion", "medium",
   "When is the witr prayer performed?",
   ["After 'Isha, as the last prayer of the night", "Immediately before the Fajr prayer only", "Directly after Maghrib every evening", "At midday, shortly before Dhuhr"]),
 q("comprehensive", 6, "Guarding Tawheed", "hard",
   "Wearing an amulet while believing it brings protection is:",
   ["an act of shirk", "a recommended precaution", "a harmless old custom", "a sunnah of the Prophet ﷺ"]),
 q("comprehensive", 6, "Guarding Tawheed", "hard",
   "Showing off in acts of worship (riya) is called:",
   ["minor shirk", "major shirk", "permissible pride", "a sign of strong faith"]),
]

def by_program():
    out = {}
    for item in NEW:
        out.setdefault((item["_prog"], item["_lvl"]), []).append(item)
    return out
