# -*- coding: utf-8 -*-
"""Assembles the v4 placement-test data (questions.json) for the one-division
curriculum. Refuses to write if any audit fails."""
import json, re, sys, collections

import fill_items

POOLS = json.load(open("remapped.json"))   # "prog|lvl" -> [q]

STRUCT = {
  "reading-tajweed": 4, "memorization": 4, "ijazah": 2,
  "foundation": 4, "advanced": 6, "comprehensive": 6,
}

CONFIG = {
  "masteryThreshold": 0.60,
  "questionsPerLevel": 10,
  "difficultyMix": {"easy": 0.3, "medium": 0.45, "hard": 0.25},
  "prerequisiteLookback": 1,
  "placementMode": "firstUnmastered",
}
MIN_POOL = 16

# ------------------------------------------------------------------ levels
LEVELS = {
 "reading-tajweed": [
  (1, "Letter & Sound Foundations", "All letters in every form, the three short vowels, blending into read words.", 22, 44),
  (2, "Elongation & Word Fluency", "Long vowels, the hamzah-triggered madd cases, tanwin, connected verse reading.", 22, 44),
  (3, "Connected Reading & Core Rules", "Sukun, shaddah, the nun and mim rule sets, stopping behaviour, madd lazim.", 22, 44),
  (4, "Fluent Recitation & Applied Mastery", "Articulation points and attributes, the full madd hierarchy, waqf and ibtida, tarteel.", 24, 48),
 ],
 "memorization": [
  (1, "Juz Amma (Juz 30)", "All 37 surahs of Juz 30 memorized with correct tajweed.", 24, 48),
  (2, "Juz 29 & Core Surahs", "Juz 29 plus the high-value surah bank (Yasin, Al-Mulk, Al-Waqi'ah, Al-Kahf).", 20, 40),
  (3, "Half-Qur'an Memorization", "Fifteen additional juz under a personal revision system.", 96, 192),
  (4, "Complete Hifz (Khatm)", "The entire Qur'an memorized, examined and publicly demonstrated.", None, None),
 ],
 "ijazah": [
  (1, "Ijazah Foundation (Pre-Sanad)", "Error-free extended recitation with detailed command of tajweed theory.", 24, 48),
  (2, "Ijazah Certification (Sanad)", "The formal chained examination before a certified Sheikh/Sheikha.", 40, 80),
 ],
 "foundation": [
  (1, "Letters & Short Vowels", "The alphabet in all forms, the three short vowels, blending, first sentences.", 12, 24),
  (2, "Long Vowels & Closed Syllables", "Vowel length, sukun, the definite article, first connected passages.", 12, 24),
  (3, "Tanwin, Shaddah & Decoding Autonomy", "The complete diacritic system; independent reading of unseen vowelled text.", 12, 24),
  (4, "Fluency, Orthography & Writing Foundations", "Fluent oral reading, hamzah spelling rules, both orthographies, dictation.", 12, 24),
 ],
 "advanced": [
  (1, "Survival Communication (PF1)", "Greetings, self, family, home and daily life in first correct exchanges.", 25, 50),
  (2, "Everyday Transactions (PF2)", "Shopping, weather, travel, health and holidays; simple past-tense narration.", 25, 50),
  (3, "Social Communication & Foundational Grammar (PF3)", "Society-level topics, the first explicit grammar system, cohesive paragraphs.", 25, 50),
  (4, "Connected Discourse & Contemporary Topics (PF4)", "Argument and opinion, the case and mood essentials, media-style comprehension.", 25, 50),
  (5, "Extended Reading & Structural Depth (PF5)", "Long texts, morphology, conditionals and passive, summary skills.", 25, 50),
  (6, "Academic Readiness & Composition (PF6)", "Advanced syntax, formal register, extended composition and debate.", 25, 50),
 ],
 "comprehensive": [
  (1, "First Foundations of Faith & Daily Practice", "Who Allah is and who His Messenger ﷺ is; first surahs, daily supplications, sunnah routines.", 36, 72),
  (2, "The Framework of the Deen", "Islam, Iman and Ihsan; the five pillars and six articles; the etiquette systems.", 36, 72),
  (3, "Evidence & the Foundations of Worship", "The three principles, complete wudu, the connected seerah arc, the creed lists.", 36, 72),
  (4, "Tawheed, Purification & the Conditions of Faith", "Tawheed and taghut, the conditions of the shahadah, tayammum, heritage literacy.", 36, 72),
  (5, "Forms of Worship & Establishing the Prayer", "Every form of worship owed to Allah alone; the adhan and the structure of salah.", 36, 72),
  (6, "Guarding Tawheed & Complete Devotional Practice", "Major and minor shirk refuted; the prayer perfected with janazah and daily adhkar.", 36, 72),
 ],
}

SELF_REPORT = {
 "reading-tajweed": ("Where is your Qur'an reading today?", [
   ("I'm just starting — the letters are still new to me", 1),
   ("I know the letters and short vowels, and read simple words", 2),
   ("I read verses, but the tajweed rules are still new to me", 3),
   ("I read fluently and apply the main tajweed rules", 4)]),
 "memorization": ("How much of the Qur'an do you currently hold in memory?", [
   ("Little or none yet — I'm beginning my memorization", 1),
   ("Most or all of Juz 'Amma (Juz 30)", 2),
   ("Juz 29 and 30, plus some core surahs (Yasin, Al-Mulk…)", 3),
   ("Many juz — well beyond Juz 29 and Juz 30", 4)]),
 "ijazah": ("Where are you in your ijazah journey?", [
   ("I completed advanced tajweed and want to begin preparing", 1),
   ("I have prepared thoroughly and seek the formal sanad examination", 2)]),
 "foundation": ("Where is your Arabic reading today?", [
   ("I'm starting from zero — the letters are new to me", 1),
   ("I know the letters and read short-vowel words", 2),
   ("I read words with long vowels and sukun", 3),
   ("I read fully vowelled sentences and am polishing fluency and spelling", 4)]),
 "advanced": ("How would you describe your Arabic ability?", [
   ("I know a few words — I can barely hold a conversation", 1),
   ("I manage greetings and simple daily exchanges", 2),
   ("I handle everyday situations — shopping, travel, plans", 3),
   ("I discuss familiar topics and can write a paragraph", 4),
   ("I argue opinions and read longer texts with a dictionary", 5),
   ("I read extended texts and write structured essays", 6)]),
 "comprehensive": ("How much structured Islamic knowledge have you studied?", [
   ("I'm at the very beginning", 1),
   ("I know the basics — the pillars, short surahs, daily du'as", 2),
   ("I've studied the foundations of belief and how to make wudu", 3),
   ("I've studied tawheed, its conditions, and purification in detail", 4),
   ("I've studied the forms of worship and the prayer in detail", 5),
   ("I've covered shirk in detail and the complete prayer, and want confirmation", 6)]),
}

TRACKS = [
 ("quran", "Qur'an", "Reading, tajweed, memorization and ijazah pathways", [
   ("reading-tajweed", "Reading & Tajweed",
    "Builds accurate, rule-governed Qur'anic reading from first letter recognition to fluent, tajweed-compliant recitation."),
   ("memorization", "Memorization & Revision",
    "A staged memorization pathway building the Qur'an into long-term memory through structured memorization and revision cycles. Open to every student — no reading requirement.", "3-5x / week recommended for faster progress"),
   ("ijazah", "Ijazah Preparation",
    "Prepares advanced reciters for a formal Ijazah — a certified, chained authorization to transmit the Qur'an."),
 ]),
 ("arabic", "Arabic Language", "Modern Standard Arabic for non-native speakers", [
   ("foundation", "Arabic Foundation",
    "Complete Arabic literacy from zero: letters, the full diacritic system, decoding autonomy, fluent vowelled reading and first writing."),
   ("advanced", "Arabic Post-Foundation",
    "Communicative Modern Standard Arabic in six levels, from survival conversation to pre-academic proficiency."),
 ]),
 ("islamic-studies", "Islamic Studies", "One comprehensive, evidence-based pathway of belief, worship, seerah and character", [
   ("comprehensive", "Comprehensive Islamic Studies",
    "An integrated six-level pathway covering belief, worship, the Prophet's life ﷺ, hadith, Qur'an knowledge, character and heritage."),
 ]),
]

# ------------------------------------------------------------------ topics
TOPIC = {
 # reading-tajweed / foundation reading strands
 "Similar Letters": "Letter Recognition", "Letter Sounds": "Letter Recognition",
 "Letters in Words": "Letter Recognition", "Letter Names": "Letter Recognition",
 "Letter Shapes": "Letter Recognition", "Alphabet Order": "Letter Recognition",
 "Reading Words": "Decoding", "Reading Syllables": "Decoding", "Word Reading": "Decoding",
 "Short Vowels": "Vowels & Marks", "Long Vowels": "Vowels & Marks", "Tanween": "Vowels & Marks",
 "Sukoon & Shaddah": "Vowels & Marks", "Shaddah & Sukoon": "Vowels & Marks",
 "Madd": "Elongation", "Madd Types": "Elongation", "Madd Precision": "Elongation",
 "Noon Rules": "Tajweed Rules", "Meem Rules": "Tajweed Rules", "Qalqalah": "Tajweed Rules",
 "Tajweed in Context": "Tajweed Application", "Tajweed Rules": "Tajweed Rules",
 "Reading Accuracy": "Fluency", "Stopping & Starting": "Waqf & Ibtida",
 "Makharij & Sifaat": "Articulation", "Applied Rules": "Tajweed Application",
 "Correction Skill": "Teaching & Diagnosis", "Ijazah Knowledge": "Transmission",
 "Advanced Application": "Tajweed Application",
 # memorization
 "Passage Recognition": "Memorization", "Passage Discrimination": "Memorization",
 "Surah Familiarity": "Qur'an Knowledge",
 # foundation/pf language strands
 "Vocabulary": "Vocabulary", "Word Groups": "Vocabulary", "Everyday Arabic": "Communication",
 "Sentences": "Reading", "Words in Context": "Reading", "Spelling & Orthography": "Orthography",
 "Conversation": "Communication", "Transactions": "Communication", "Travel": "Communication",
 "Health": "Communication", "Numbers": "Vocabulary", "Verbs": "Grammar",
 "Sentence Formation": "Grammar", "Nouns & Adjectives": "Grammar", "Grammar": "Grammar",
 "Reading Comprehension": "Reading", "Advanced Reading": "Reading", "Expression": "Composition",
 "Advanced Grammar": "Grammar", "Morphology": "Morphology",
}
IS_TOPIC = {
 "Belief": "Aqeedah", "Belief in Allah": "Aqeedah", "Foundations of Belief": "Aqeedah",
 "Pillars of Iman": "Aqeedah", "Pillars & Basics": "Aqeedah", "Pillars & Practice": "Aqeedah",
 "Angels & Books": "Aqeedah", "Angels and Books": "Aqeedah", "Prophets": "Aqeedah",
 "Tawheed & Belief": "Aqeedah", "Categories of Tawheed": "Aqeedah", "Tawheed & Qadar": "Aqeedah",
 "Names and Attributes": "Aqeedah", "Shirk": "Aqeedah", "Last Day and Qadar": "Aqeedah",
 "Signs of the Hour": "Aqeedah", "Qadar Applied": "Aqeedah", "Applied Aqeedah": "Aqeedah",
 "Guarding Tawheed": "Aqeedah",
 "Wudu": "Worship & Practice", "Purity": "Worship & Practice", "Tayammum": "Worship & Practice",
 "Salah": "Worship & Practice", "Worship": "Worship & Practice", "Worship Basics": "Worship & Practice",
 "Prayer": "Worship & Practice", "Salah & Adhan": "Worship & Practice",
 "Forms of Worship": "Worship & Practice", "Salah Completion": "Worship & Practice",
 "Fiqh & Zakah": "Worship & Practice", "Zakah": "Worship & Practice", "Fasting": "Worship & Practice",
 "Early Life": "Seerah", "Key Events": "Seerah", "Key People": "Seerah", "Migration": "Seerah",
 "Companions": "Seerah", "Seerah": "Seerah", "Dates & Sequence": "Seerah", "Dates & Timeline": "Seerah",
 "Battles": "Seerah", "Treaties & Covenants": "Seerah", "Farewell Sermon": "Seerah",
 "Lessons & Significance": "Seerah", "Historical Understanding": "Seerah",
 "Hadith Basics": "Hadith", "The Sunnah": "Hadith", "Famous Hadith": "Hadith",
 "Hadith Foundations": "Hadith", "Qur'an & Hadith": "Hadith",
 "Hadith Compilers": "Heritage", "Collections & Scholars": "Heritage", "The Six Books": "Heritage",
 "Hadith Collections": "Heritage", "Hadith Sciences": "Heritage",
 "Surah Themes": "Qur'an Knowledge", "Central Message": "Qur'an Knowledge",
 "Prophet & Qur'an": "Qur'an Knowledge", "Qur'an Sciences": "Qur'an Knowledge",
 "Qur'an Knowledge": "Qur'an Knowledge",
 "Manners & Du'a": "Manners & Character", "Manners & Family": "Manners & Character",
 "Eating & Drinking": "Manners & Character", "Kindness & Care": "Manners & Character",
 "Greetings & Speech": "Manners & Character", "Masjid Manners": "Manners & Character",
 "Home & Guests": "Manners & Character", "Speech & Slander": "Manners & Character",
 "Patience & Forgiveness": "Manners & Character", "Trust & Truthfulness": "Manners & Character",
 "Humility & Conduct": "Manners & Character", "Character Terms": "Manners & Character",
 "Applying Character": "Manners & Character", "Parents & Family": "Manners & Character",
}

def topic_of(prog, skill):
    if prog == "comprehensive":
        return IS_TOPIC.get(skill, "General")
    return TOPIC.get(skill, "General")

COMPETENCY = {
 ("reading-tajweed", 1): "Identify and articulate every letter in all forms with the three short vowels",
 ("reading-tajweed", 2): "Control vowel length: madd cases and tanwin in connected reading",
 ("reading-tajweed", 3): "Apply the notation-driven rules (sukun, shaddah, nun/mim sets, stopping) in real text",
 ("reading-tajweed", 4): "Recite with tarteel: articulation, full madd hierarchy, waqf & ibtida",
 ("memorization", 1): "Hold Juz 30 in accurate memory",
 ("memorization", 2): "Hold Juz 29 and the core surah bank in accurate memory",
 ("memorization", 3): "Hold fifteen additional juz under active revision",
 ("memorization", 4): "Hold the complete Qur'an in examined memory",
 ("ijazah", 1): "Recite at examination grade and explain the governing ahkam",
 ("ijazah", 2): "Complete the formal chained certification",
 ("foundation", 1): "Recognize and sound every letter; blend short-vowel words",
 ("foundation", 2): "Decode long vowels and closed syllables; read connected passages",
 ("foundation", 3): "Decode the complete diacritic system independently",
 ("foundation", 4): "Read fluently and apply the spelling system in both orthographies",
 ("advanced", 1): "Communicate about self and daily life in short correct exchanges",
 ("advanced", 2): "Handle everyday transactions and narrate simple past events",
 ("advanced", 3): "Discuss social topics using the foundational grammar system",
 ("advanced", 4): "Argue and justify with case/mood control and media comprehension",
 ("advanced", 5): "Read extended texts with morphological and structural depth",
 ("advanced", 6): "Operate at pre-academic level: advanced syntax, register, composition",
 ("comprehensive", 1): "State the first certainties of faith and live the daily sunnah practices",
 ("comprehensive", 2): "Command the framework of the deen: pillars, articles and etiquette",
 ("comprehensive", 3): "Evidence the three principles, perform wudu, narrate the seerah arc",
 ("comprehensive", 4): "Explain tawheed with its conditions and complete purification",
 ("comprehensive", 5): "Attribute all worship to Allah alone and establish the prayer",
 ("comprehensive", 6): "Refute shirk and perform the complete devotional system",
}

# ------------------------------------------------------------------ audits
errors, warnings = [], []
LEAK_WORDS = ("all of the above", "none of the above")

def audit_question(qid, q, prompt_index, scope):
    opts = q["options"]
    c = q["correct"]
    if len(opts) < 4: errors.append(f"{qid}: only {len(opts)} options")
    if len(set(opts)) != len(opts): errors.append(f"{qid}: duplicate options")
    if not isinstance(c, int) or not (0 <= c < len(opts)):
        errors.append(f"{qid}: correct index out of range"); return
    if q["difficulty"] not in ("easy", "medium", "hard"):
        errors.append(f"{qid}: difficulty '{q['difficulty']}'")
    lens = [len(o) for o in opts]
    others = [lens[i] for i in range(len(opts)) if i != c]
    if q.get("options_arabic") or q.get("optionsArabic"):
        if min(lens) >= 25 and max(lens) > 2.0 * min(lens):
            errors.append(f"{qid}: passage options too uneven ({min(lens)}..{max(lens)})")
    else:
        if lens[c] > max(others) + 14:
            errors.append(f"{qid}: correct option {lens[c]-max(others)} chars longer: {opts[c][:60]}")
        if lens[c] + 14 < min(others):
            errors.append(f"{qid}: correct option much shorter: {opts[c][:60]}")
    for o in opts:
        if o.strip().lower() in LEAK_WORDS:
            errors.append(f"{qid}: '{o}' banned option")
    if len(opts[c]) > 14 and opts[c].lower() in q["prompt"].lower():
        errors.append(f"{qid}: prompt contains the answer")
    key = (scope, q["prompt"].strip().lower(), (q.get("arabic") or "").strip(),
           tuple(sorted(o.strip().lower() for o in opts)))
    if key in prompt_index:
        errors.append(f"{qid}: identical to {prompt_index[key]}")
    prompt_index[key] = qid

# ------------------------------------------------------------------ build
fills = fill_items.by_program()
out_tracks = []
all_ids = set()
prompt_index = {}
stats = []
PREFIX = {"reading-tajweed": "RT", "memorization": "MEM", "ijazah": "IJZ",
          "foundation": "AF", "advanced": "PF", "comprehensive": "IS"}

for tid, tlabel, tagline, progs in TRACKS:
    tr = {"id": tid, "label": tlabel, "icon": tid, "tagline": tagline, "programs": []}
    for entry in progs:
        pid, plabel, pdesc = entry[0], entry[1], entry[2]
        prog = {"id": pid, "label": plabel, "description": pdesc,
                "levels": [], "selfReport": {}, "levelBanks": []}
        if len(entry) > 3: prog["fastPaceNote"] = entry[3]
        if pid == "memorization":
            prog["accessNote"] = ("Independently accessible — no Qur'an reading ability or prior "
                                  "program is required. Placement is by memorization status.")
        for lv, name, focus, weeks, lessons in LEVELS[pid]:
            prog["levels"].append({"id": lv, "name": name, "desc": focus,
                                   "weeks": weeks, "lessons": lessons})
        sr_prompt, sr_opts = SELF_REPORT[pid]
        prog["selfReport"] = {"prompt": sr_prompt,
                              "options": [{"label": l, "claimLevel": c} for l, c in sr_opts]}
        seq = 0
        for lv, name, focus, _w, _l in LEVELS[pid]:
            pool = list(POOLS.get(f"{pid}|{lv}", []))
            pool += fills.get((pid, lv), [])
            questions = []
            rot = 0
            for raw in pool:
                seq += 1
                qid = "%s_L%d_%03d" % (PREFIX[pid], lv, seq)
                audit_question(qid, raw, prompt_index, pid)
                if qid in all_ids: errors.append(f"dup id {qid}")
                all_ids.add(qid)
                opts = list(raw["options"])
                shift = (raw["correct"] + rot) % len(opts)
                rot += 1
                opts = opts[shift:] + opts[:shift]
                correct = (raw["correct"] - shift) % len(raw["options"])
                item = {"id": qid, "track": tid, "program": pid, "level": lv,
                        "skill": raw["skill"], "topic": topic_of(pid, raw["skill"]),
                        "competency": COMPETENCY[(pid, lv)],
                        "difficulty": raw["difficulty"], "type": "mcq",
                        "prompt": raw["prompt"], "options": opts, "correct": correct,
                        "correctAnswer": opts[correct], "points": 1}
                if raw.get("arabic"): item["arabic"] = raw["arabic"]
                if raw.get("options_arabic") or raw.get("optionsArabic"):
                    item["optionsArabic"] = True
                questions.append(item)
            n = len(questions)
            serve = CONFIG["questionsPerLevel"]
            if n < serve: errors.append(f"{pid} L{lv}: pool {n} < {serve} served")
            elif n < MIN_POOL: warnings.append(f"{pid} L{lv}: pool {n}, target {MIN_POOL}")
            diffs = {d: sum(1 for x in questions if x["difficulty"] == d)
                     for d in ("easy", "medium", "hard")}
            if sum(1 for v in diffs.values() if v == 0) > 1:
                warnings.append(f"{pid} L{lv}: difficulty spread {diffs}")
            skills = sorted({x["skill"] for x in questions})
            if len(skills) < 2: warnings.append(f"{pid} L{lv}: single skill {skills}")
            ar_items = [x for x in questions if x.get("optionsArabic")]
            if len(ar_items) >= 6:
                cor = [len(x["options"][x["correct"]]) for x in ar_items]
                dis = [len(o) for x in ar_items for i, o in enumerate(x["options"]) if i != x["correct"]]
                mc, md = sum(cor)/len(cor), sum(dis)/len(dis)
                if abs(mc - md) / md > 0.15:
                    errors.append(f"{pid} L{lv}: Arabic-option length bias {mc:.0f} vs {md:.0f}")
            prog["levelBanks"].append({"level": lv, "name": name, "focus": focus,
                                       "questions": questions})
            stats.append((tid, pid, lv, n, diffs, len(skills)))
        tr["programs"].append(prog)
    out_tracks.append(tr)

out = {"meta": {"academy": "Fosselat Academy", "version": "4.0",
                "division": "student", "config": CONFIG},
       "tracks": out_tracks}

if warnings:
    print("WARNINGS:")
    for w in warnings: print("  -", w)
if errors:
    print("ERRORS:")
    for e in errors[:80]: print("  -", e)
    print(f"({len(errors)} total)")
    sys.exit(1)

json.dump(out, open("questions.json", "w"), ensure_ascii=False, indent=1)
total = len(all_ids)
print(f"OK — {total} questions")
print("%-16s %-3s %5s  %s" % ("program", "L", "pool", "e/m/h  skills"))
for tid, pid, lv, n, d, sk in stats:
    print("%-16s L%-2d %5d  %d/%d/%d   %d" % (pid, lv, n, d["easy"], d["medium"], d["hard"], sk))
print("wrote questions.json")
